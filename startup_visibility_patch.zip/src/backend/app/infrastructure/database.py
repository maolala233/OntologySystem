from sqlalchemy import Column, Integer, String, Boolean, Text, JSON, DateTime, ForeignKey, Enum, UniqueConstraint, LargeBinary, Numeric, Text as SQLAlchemyText
from sqlalchemy import text as sa_text
from sqlalchemy.dialects.mysql import VARCHAR, LONGTEXT
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy import create_engine
import datetime
import time
import bcrypt
from app.core.config import settings
from app.core.logging import logger

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, index=True)
    hashed_password = Column(String(255))
    is_active = Column(Boolean, default=True)
    # M1 权限模型（docs/design/02 §3.1）
    role = Column(Enum("admin", "user", name="user_role"), nullable=False, server_default="user")
    email = Column(String(255), unique=True, nullable=True)
    display_name = Column(String(64), nullable=True)
    locale = Column(String(10), nullable=False, server_default="zh-CN")
    last_login_at = Column(DateTime, nullable=True)
    # R12：用户被应用的角色预设（角色配置 apply 时写入；用户管理列表展示用）
    app_role_id = Column(Integer, ForeignKey("roles.id"), nullable=True)

    projects = relationship("Project", back_populates="owner")

class Project(Base):
    __tablename__ = "projects"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), index=True)
    description = Column(String(500), nullable=True)
    owner_id = Column(Integer, ForeignKey("users.id"))
    domain_id = Column(Integer, ForeignKey("knowledge_domains.id"), nullable=True)  # 知识域 ID
    domains = Column(String(500), nullable=True)  # 知识域名称（冗余字段，用于快速访问，如"IT 架构，财务规范"）
    
    # 图谱数据（JSON 格式，用于前端 React Flow 渲染）
    graph_data = Column(JSON, nullable=True)
    
    # TTL 文件内容（同步到 Neo4j 之前的最终形态）
    ttl_content = Column(LONGTEXT, nullable=True)
    
    # RAGFlow 注入配置
    inject_config = Column(JSON, nullable=True)
    
    is_published = Column(Boolean, default=False)
    # M3-6 R6（02 §3.3）：项目状态机 + 当前版本指针（is_published 兼容期并存，写路径以 status/publications 为准）
    status = Column(Enum("draft", "building", "ready", "published", name="project_status"),
                    nullable=False, server_default="draft")
    current_version_id = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    owner = relationship("User", back_populates="projects")
    domain = relationship("KnowledgeDomain", back_populates="projects")

class KnowledgeDomain(Base):
    """
    知识域字典表
    用于标识本体项目所属的知识领域，如"IT 架构"、"财务规范"等
    """
    __tablename__ = "knowledge_domains"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, index=True, nullable=False)  # 知识域名称
    description = Column(String(500), nullable=True)  # 知识域描述
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    
    # 关联项目
    projects = relationship("Project", back_populates="domain")


class SystemConfig(Base):
    __tablename__ = "system_configs"
    id = Column(Integer, primary_key=True, index=True)
    key = Column(String(100), unique=True, index=True)  # e.g., 'llm_config'
    value = Column(JSON, nullable=False)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)


class UploadedDocument(Base):
    """
    已上传文档记录表
    用于跟踪项目中上传的文档，支持文档管理（查看列表、删除等）
    M3-1（docs/design/02 §3.4，R4）：原件/解析文本落 MinIO（storage_key/text_key），
    sha256 同项目秒传判重，parse_status 解析状态机（M3-2 parse 队列驱动）。
    """
    __tablename__ = "uploaded_documents"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    filename = Column(String(255), nullable=False)  # 原始文件名
    file_path = Column(String(500), nullable=False)  # 旧本地路径（兼容期保留；新上传以 storage_key 为准）
    file_size = Column(Integer, nullable=True)  # 文件大小（字节）
    file_type = Column(String(50), nullable=True)  # 文件类型：txt, pdf, doc, docx, xlsx, xls, csv, pptx, md
    text_content = Column(LONGTEXT, nullable=True)  # 解析后的文本内容（兼容期保留，text_key 就绪后清空）

    # R4 加列（02 §3.4）
    storage_key = Column(String(512), nullable=True)  # MinIO ontology-uploads 键：{project}/{uuid}.{ext}
    text_key = Column(String(512), nullable=True)     # MinIO ontology-parsed 键：解析文本（M3-2 写入）
    sha256 = Column(String(64), nullable=True, index=True)  # 内容哈希，同项目秒传判重
    parse_status = Column(
        Enum("uploaded", "parsing", "parsed", "failed", name="doc_parse_status"),
        nullable=False, server_default="uploaded",
    )
    parse_error = Column(Text, nullable=True)
    page_count = Column(Integer, nullable=True)
    language = Column(String(10), nullable=True)   # zh/en/mixed（M3-2 解析时回填）
    parse_backend = Column(String(32), nullable=True)  # docling_ocr/docling/pymupdf4llm/vl_model/native（M3-2）
    deleted_at = Column(DateTime, nullable=True)   # 软删标记
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    # 关联项目
    project = relationship("Project", back_populates="documents")
    chunks = relationship("DocumentChunk", back_populates="document",
                          cascade="all, delete-orphan", order_by="DocumentChunk.chunk_index")


class DocumentChunk(Base):
    """长文档切片（02 §3.4，R4）：抽取与向量化的统一单位，M3-2 parse 队列写入。"""
    __tablename__ = "document_chunks"

    id = Column(Integer, primary_key=True, index=True)
    document_id = Column(Integer, ForeignKey("uploaded_documents.id", ondelete="CASCADE"), nullable=False)
    chunk_index = Column(Integer, nullable=False)
    text = Column(Text, nullable=False)
    char_start = Column(Integer, nullable=False, server_default="0")  # 原文偏移（溯源定位用）
    char_end = Column(Integer, nullable=False, server_default="0")
    token_count = Column(Integer, nullable=True)
    meta = Column(JSON, nullable=True)  # 章节路径/页码/表格标记
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))

    document = relationship("UploadedDocument", back_populates="chunks")
    __table_args__ = (
        UniqueConstraint("document_id", "chunk_index", name="uk_doc_chunk"),
    )


# 更新 Project 模型，添加 documents 关系
Project.documents = relationship("UploadedDocument", back_populates="project", cascade="all, delete-orphan")


class Module(Base):
    """功能模块字典（M1，docs/design/02 §3.1）：14 个模块码见 docs/design/README §4.1。"""
    __tablename__ = "modules"

    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(32), unique=True, nullable=False, index=True)
    name = Column(String(64), nullable=False)
    description = Column(String(255), nullable=True)
    is_default_on = Column(Boolean, nullable=False, server_default="0")
    sort_order = Column(Integer, nullable=False, server_default="0")


class Role(Base):
    """角色 = 模块授权预设（R8）：应用角色即按 module_codes 全量生成用户 grants
    （允许列表内 allowed=1，其余模块 allowed=0，角色即真相，覆盖既有微调）。"""
    __tablename__ = "roles"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(64), unique=True, nullable=False)
    description = Column(String(255), nullable=True)
    module_codes = Column(JSON, nullable=False)  # 允许的模块码列表（MySQL JSON 列无默认值，应用层保证）
    is_builtin = Column(Boolean, nullable=False, server_default="0")  # 内置角色不可删、不可改名
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


class UserModuleGrant(Base):
    """用户 × 模块授权矩阵（M1）：显式 allow/deny 可覆盖 is_default_on。"""
    __tablename__ = "user_module_grants"
    __table_args__ = (UniqueConstraint("user_id", "module_code", name="uk_user_module"),)

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    module_code = Column(String(32), nullable=False)
    allowed = Column(Boolean, nullable=False, server_default="1")
    granted_by = Column(Integer, nullable=False)
    granted_at = Column(DateTime, default=datetime.datetime.utcnow)


class ProjectMember(Base):
    """项目级协作权限（M1）：owner 与 projects.owner_id 冗余同步（服务层维护）。"""
    __tablename__ = "project_members"
    __table_args__ = (UniqueConstraint("project_id", "user_id", name="uk_proj_user"),)

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    role = Column(Enum("owner", "editor", "viewer", name="project_role"), nullable=False)
    created_by = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


class ModelConfig(Base):
    """模型配置（M2，docs/design/02 §3.2）：本地(Ollama/vLLM)与远程(OpenAI兼容)统一抽象。

    api_key 仅存 AES-256-GCM 密文（core/security）；明文只在解析结果内存中流转。
    抽取运行参数（chunk_size/request_interval/llm_timeout/disable_think/streaming_enabled）
    存放于 params JSON（extract 行）。
    """
    __tablename__ = "model_configs"

    id = Column(Integer, primary_key=True, index=True)
    scope = Column(Enum("global", "project", name="model_scope"), nullable=False, server_default="global")
    project_id = Column(Integer, nullable=True)
    purpose = Column(Enum("chat", "extract", "embedding", "vl", name="model_purpose"), nullable=False)
    name = Column(String(64), nullable=False)
    provider = Column(String(32), nullable=False)
    base_url = Column(String(512), nullable=False)
    api_key_encrypted = Column(LargeBinary(1024), nullable=True)
    model_name = Column(String(128), nullable=False)
    params = Column(JSON, nullable=True)
    dims = Column(Integer, nullable=True)
    is_default = Column(Boolean, nullable=False, server_default="0")
    enabled = Column(Boolean, nullable=False, server_default="1")
    last_test_at = Column(DateTime, nullable=True)
    last_test_ok = Column(Boolean, nullable=True)
    created_by = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)


class UserModelPick(Base):
    """用户个人模型选择（R14）：普通用户从全局 model_configs 里挑一个作为
    个人抽取模型，该用户发起的 schema/instance 抽取任务按此解析；
    未设置时回落项目默认 → 全局默认（provider._pick_default）。
    purpose 复用 model_purpose 枚举扩展预留（chat/vl），当前仅 extract 有入口。
    """
    __tablename__ = "user_model_picks"
    __table_args__ = (UniqueConstraint("user_id", "purpose", name="uk_user_pick_purpose"),)

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    purpose = Column(Enum("chat", "extract", "embedding", "vl", name="model_purpose"),
                     nullable=False)
    config_id = Column(Integer, ForeignKey("model_configs.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)


class Entity(Base):
    """实体行表（M3-3 R5，docs/design/02 §3.5）：graph_data blob 的拆行事实源。

    消解/审核/导出以行表为准，Neo4j/Milvus/Oxigraph 为其投影（02 §4 三阶段迁移）。
    uri = urn:onto:{project_id}:entity/{graph_data 节点 id}，节点 id 由抽取侧
    make_deterministic_id 或画布保证稳定。is_class_node 判据 data.type ∈
    {owl:Class, Class}（TBox；历史动作类型已废弃）；owl:NamedIndividual/Instance 为 ABox。
    """
    __tablename__ = "entities"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False)
    uri = Column(String(512), nullable=False)
    label = Column(String(255), nullable=False)
    label_normalized = Column(String(255), nullable=False)
    class_label = Column(String(128), nullable=False)
    aliases = Column(JSON, nullable=True)
    props = Column(JSON, nullable=True)
    confidence = Column(Numeric(4, 3), nullable=True)  # 0-1，LLM 自报
    status = Column(Enum("auto", "merged", "pending_review", "approved", "rejected",
                         name="entity_status"), nullable=False, server_default="auto")
    canonical_id = Column(Integer, ForeignKey("entities.id", ondelete="SET NULL"), nullable=True)
    is_class_node = Column(Boolean, nullable=False, server_default="0")
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))
    updated_at = Column(DateTime, nullable=False,
                        server_default=sa_text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))

    __table_args__ = (
        UniqueConstraint("project_id", "uri", name="uk_proj_uri"),
    )


class Relation(Base):
    """关系行表（02 §3.5）：subject/object 外键实体；双向边判定在后端（06 §4.4）。"""
    __tablename__ = "relations"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False)
    subject_id = Column(Integer, ForeignKey("entities.id", ondelete="CASCADE"), nullable=False)
    predicate = Column(String(128), nullable=False)
    object_id = Column(Integer, ForeignKey("entities.id", ondelete="CASCADE"), nullable=False)
    props = Column(JSON, nullable=True)
    confidence = Column(Numeric(4, 3), nullable=True)
    status = Column(Enum("auto", "pending_review", "approved", "rejected",
                         name="relation_status"), nullable=False, server_default="auto")
    is_class_edge = Column(Boolean, nullable=False, server_default="0")
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))

    __table_args__ = (
        UniqueConstraint("project_id", "subject_id", "predicate", "object_id", name="uk_proj_edge"),
    )


class ProvenanceRecord(Base):
    """溯源记录（02 §3.6）：W3C PROV-O 对齐，evidence 定位到原句（修复缺陷 #11）。"""
    __tablename__ = "provenance_records"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False)
    target_type = Column(Enum("entity", "relation", "chunk", name="prov_target_type"),
                         nullable=False)
    target_id = Column(Integer, nullable=False)
    source_document_id = Column(Integer, ForeignKey("uploaded_documents.id", ondelete="CASCADE"),
                                nullable=False)
    chunk_index = Column(Integer, nullable=True)
    evidence_text = Column(String(1024), nullable=True)
    char_start = Column(Integer, nullable=True)
    char_end = Column(Integer, nullable=True)
    extraction_method = Column(String(32), nullable=True)  # llm_ner/llm_re/manual/merge
    checksum = Column(String(64), nullable=False)  # SHA-256(对象键|偏移|证据)，防篡改
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))


class ReviewItem(Base):
    """人工审核队列（02 §3.6）：8 种触发原因；状态机 pending→claimed→approved/rejected/edited。

    冲突不单独建表：ConflictDetector 检出项物化为 review_items(item_type='conflict_*')。
    """
    __tablename__ = "review_items"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False)
    item_type = Column(Enum("entity_merge", "new_class", "new_predicate",
                            "low_confidence_entity", "low_confidence_relation",
                            "conflict_value", "conflict_type", "conflict_relationship",
                            "missing_evidence", "conflict_axiom", "axiom_suggestion",
                            "schema_match_suggestion", "cq_suggestion",
                            name="review_item_type"), nullable=False)
    payload = Column(JSON, nullable=False)
    reason = Column(String(255), nullable=True)
    priority = Column(Enum("low", "medium", "high", "critical", name="review_priority"),
                      nullable=False, server_default="medium")
    status = Column(Enum("pending", "claimed", "approved", "rejected", "edited",
                         name="review_status"), nullable=False, server_default="pending")
    suggested_action = Column(JSON, nullable=True)
    assigned_to = Column(Integer, nullable=True)
    decided_by = Column(Integer, nullable=True)
    decided_at = Column(DateTime, nullable=True)
    result_ref = Column(JSON, nullable=True)
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))


class OntologyVersion(Base):
    """版本控制（M3-6 R6，docs/design/02 §3.7）：修订画布/抽取完成/发布前/回滚前强制落版本。

    version_no 项目内自增；快照正文入 MinIO（schema_snapshot_key/full_snapshot_key），
    行表只存 key + stats + checksum（不可变副本）。
    """
    __tablename__ = "ontology_versions"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False)
    version_no = Column(Integer, nullable=False)
    label = Column(String(64), nullable=True)
    kind = Column(Enum("schema", "full", "publication", "rollback", "manual", name="version_kind"),
                  nullable=False)
    schema_snapshot_key = Column(String(512), nullable=True)
    full_snapshot_key = Column(String(512), nullable=True)
    stats = Column(JSON, nullable=True)  # {classes, properties, instances, relations}
    checksum = Column(String(64), nullable=False)
    parent_version_id = Column(Integer, nullable=True)
    created_by = Column(Integer, nullable=False)
    description = Column(String(500), nullable=True)
    # O3-B14：候选版本 vN-cK（重抽/修改的候选），不更新 project.current_version_id
    is_candidate = Column(Boolean, nullable=False, server_default="0")
    gate_status = Column(String(16), nullable=True)  # pending | passed | rejected
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))

    __table_args__ = (
        UniqueConstraint("project_id", "version_no", name="uk_proj_ver"),
    )


class GraphSnapshot(Base):
    """图快照（02 §3.7）：发布/回滚/备份的不可变副本，MinIO 存储。"""
    __tablename__ = "graph_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False)
    version_id = Column(Integer, nullable=True)
    purpose = Column(Enum("version", "publication", "pre_rollback", "backup",
                          name="snapshot_purpose"), nullable=False)
    storage_key = Column(String(512), nullable=False)
    node_count = Column(Integer, nullable=False)
    edge_count = Column(Integer, nullable=False)
    checksum = Column(String(64), nullable=False)
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))


class Publication(Base):
    """发布记录（02 §3.7）：发布即固化快照，公共区一律读快照（只读）。"""
    __tablename__ = "publications"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False)
    version_id = Column(Integer, nullable=False)
    snapshot_id = Column(Integer, nullable=False)
    status = Column(Enum("published", "unpublished", name="publication_status"),
                    nullable=False, server_default="published")
    note = Column(String(500), nullable=True)
    published_by = Column(Integer, nullable=False)
    published_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))
    unpublished_at = Column(DateTime, nullable=True)


class OutboxEvent(Base):
    """事务性 Outbox（02 §3.8）：API 事务内写入，worker-graph/worker-rdf 消费（M4 接线）。"""
    __tablename__ = "outbox_events"

    id = Column(Integer, primary_key=True, index=True)
    aggregate_type = Column(Enum("project", "entity", "relation", "document",
                                 "publication", "version", name="outbox_aggregate"),
                            nullable=False)
    aggregate_id = Column(Integer, nullable=False)
    event_type = Column(String(64), nullable=False)
    payload = Column(JSON, nullable=False)
    status = Column(Enum("pending", "processed", "failed", name="outbox_status"),
                    nullable=False, server_default="pending")
    attempts = Column(Integer, nullable=False, server_default="0")
    last_error = Column(Text, nullable=True)
    trace_id = Column(String(64), nullable=True)
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))
    processed_at = Column(DateTime, nullable=True)


class AuditLog(Base):
    """审计日志（02 §3.8）：安全事件与治理动作全量留痕（review.decide/publish/rollback…）。"""
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, nullable=True)
    action = Column(String(64), nullable=False)
    resource_type = Column(String(32), nullable=True)
    resource_id = Column(String(64), nullable=True)
    detail = Column(JSON, nullable=True)
    ip = Column(String(45), nullable=True)
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))


class GraphLayout(Base):
    """服务端预布局结果（02 §3.8；>25k 节点，M4 graph_layouts 消费）。"""
    __tablename__ = "graph_layouts"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False)
    algorithm = Column(String(32), nullable=False, server_default="fa2")
    layout = Column(JSON, nullable=True)
    node_count = Column(Integer, nullable=False)
    status = Column(Enum("pending", "done", "failed", name="layout_status"),
                    nullable=False, server_default="pending")
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))


class McpToken(Base):
    """MCP 网关令牌（M5 R7，02 §3.9 / 07 §3.2）：user+project+读写范围 绑定。

    明文 sk-mcp- 前缀 40 字符只在签发响应出现一次，库内仅存 SHA-256。
    """
    __tablename__ = "mcp_tokens"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, nullable=False)
    name = Column(String(64), nullable=False)
    token_hash = Column(String(64), nullable=False, unique=True)  # SHA-256(sk-mcp-*)
    project_id = Column(Integer, nullable=False)
    can_write = Column(Boolean, nullable=False, server_default=sa_text("0"))
    expires_at = Column(DateTime, nullable=True)
    last_used_at = Column(DateTime, nullable=True)
    revoked_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))


class QaHistory(Base):
    """问答历史（M5 R7，03 §15 GET /qa/history 契约的存储）。"""
    __tablename__ = "qa_history"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False)
    user_id = Column(Integer, nullable=True)
    conversation_id = Column(String(36), nullable=True)  # 对话分组（R8：一次会话一个 uuid）
    question = Column(Text, nullable=False)
    answer = Column(Text, nullable=True)
    sources = Column(JSON, nullable=True)  # 引用列表（含溯源定位）
    model = Column(String(128), nullable=True)
    latency_ms = Column(Integer, nullable=True)
    confidence = Column(Numeric(4, 3), nullable=True)
    # O3-B15/B16：自修复与失败轨迹数据源（R19 e9f0a1b2c3d4）
    status = Column(Enum("ok", "repaired", "failed", name="qa_status"),
                    nullable=False, server_default="ok")
    repaired_rounds = Column(Integer, nullable=False, server_default="0")
    error = Column(Text, nullable=True)
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))


# 14 个功能模块种子（M1 R2 迁移同样写入，保持两处一致；README §4.1）
MODULE_SEEDS = [
    {"code": "dashboard",       "name": "工作台",          "description": "首页统计与快捷入口",     "is_default_on": True,  "sort_order": 1},
    {"code": "projects",        "name": "项目管理",        "description": "项目创建与列表",         "is_default_on": True,  "sort_order": 2},
    {"code": "documents",       "name": "文档管理",        "description": "上传/解析/分块",         "is_default_on": False, "sort_order": 3},
    {"code": "schema_build",    "name": "骨架构建",        "description": "TBox 抽取与画布修订",    "is_default_on": False, "sort_order": 4},
    {"code": "instance_build",  "name": "实例构建",        "description": "ABox 抽取",              "is_default_on": False, "sort_order": 5},
    {"code": "resolution",      "name": "实体消解与冲突",  "description": "消解三层流水线与冲突检测", "is_default_on": False, "sort_order": 6},
    {"code": "review",          "name": "人工审核",        "description": "审核队列与裁决",         "is_default_on": False, "sort_order": 7},
    {"code": "version_control", "name": "版本与时间轴",    "description": "快照/diff/回滚/时间线",  "is_default_on": False, "sort_order": 8},
    {"code": "publish",         "name": "发布管理",        "description": "发布到公共区",           "is_default_on": False, "sort_order": 9},
    {"code": "asset_center",    "name": "公共资产中心",    "description": "浏览已发布本体",         "is_default_on": True,  "sort_order": 10},
    {"code": "graph_explore",   "name": "图谱探索",        "description": "大规模图只读探索",       "is_default_on": False, "sort_order": 11},
    {"code": "qa",              "name": "本体问答",        "description": "基于本体的 GraphRAG 问答", "is_default_on": False, "sort_order": 12},
    {"code": "mcp",             "name": "MCP 工具",        "description": "MCP 令牌与工具调用",     "is_default_on": False, "sort_order": 13},
    {"code": "export",          "name": "导出",            "description": "18 种格式导出",          "is_default_on": False, "sort_order": 14},
    {"code": "report",          "name": "报告生成",        "description": "基于本体的主题分析报告（Word/MD）", "is_default_on": False, "sort_order": 15},
    {"code": "ppt",             "name": "PPT生成",         "description": "基于本体的主题演示文稿（PPT）", "is_default_on": False, "sort_order": 16},
    {"code": "builder_pro",     "name": "专家构建工作台",   "description": "多 Tab 专家模式（文档/骨架/实例/时间轴/审核细粒度操作），未授权用户仅使用新版一键详情页", "is_default_on": False, "sort_order": 17},
]


def init_knowledge_domains(db):
    """
    初始化知识域字典数据
    创建一些常用的知识域分类
    """
    try:
        # 检查是否已有知识域数据
        domain_count = db.query(KnowledgeDomain).count()
        if domain_count > 0:
            print(f"ℹ️ [KnowledgeDomain] Found {domain_count} existing domains, skipping initialization")
            return
        
        print("📝 [KnowledgeDomain] Creating initial knowledge domains...")
        
        # 创建常用知识域
        initial_domains = [
            KnowledgeDomain(name="IT 架构", description="信息技术架构相关的知识领域"),
            KnowledgeDomain(name="财务规范", description="财务管理与规范相关的知识领域"),
            KnowledgeDomain(name="医疗健康", description="医疗健康行业相关的知识领域"),
            KnowledgeDomain(name="教育培训", description="教育培训行业相关的知识领域"),
            KnowledgeDomain(name="制造业", description="制造业相关的知识领域"),
            KnowledgeDomain(name="金融服务", description="金融服务行业相关的知识领域"),
            KnowledgeDomain(name="法律合规", description="法律与合规相关的知识领域"),
            KnowledgeDomain(name="通用领域", description="通用知识领域，适用于跨行业场景"),
        ]
        
        for domain in initial_domains:
            db.add(domain)
        
        db.commit()
        print("✅ [KnowledgeDomain] Initial knowledge domains created")
        for domain in initial_domains:
            print(f"   - {domain.name}: {domain.description}")
            
    except Exception as e:
        print(f"⚠️ [KnowledgeDomain] Failed to create initial domains: {e}")
        db.rollback()

# 数据库连接 —— M0 统一走 settings.DATABASE_URL（src/backend/.env 环境变量驱动，
# 删除原来的 os.getenv 重复拼接逻辑，docs/design/02 §3）
DB_URL = settings.DATABASE_URL
print(f"🔧 [Database] Using connection URL: {DB_URL}")

# 根据数据库类型选择合适的参数
if DB_URL.startswith("mysql"):
    engine = create_engine(
        DB_URL,
        pool_pre_ping=True,
        pool_recycle=3600,
        pool_size=20,
        max_overflow=10,
        pool_timeout=30,
    )

    from sqlalchemy import event as _sa_event

    @_sa_event.listens_for(engine, "connect")
    def _widen_mysql_timeouts(dbapi_conn, _connection_record):
        """会话级放宽读写超时：远程 MySQL 默认 net_read_timeout=30s，长事务
        （写画布+行表双写等）执行稍慢即被服务端掐断，报 2013 Lost connection
        （2026-11-06 d17 实测）。只影响本会话，不碰全局变量。"""
        try:
            cur = dbapi_conn.cursor()
            cur.execute("SET SESSION net_read_timeout=600, net_write_timeout=600")
            cur.close()
        except Exception:  # noqa: BLE001 —— 老库/代理无权限时静默跳过
            pass
else:
    engine = create_engine(DB_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def _run_migrations() -> None:
    """M0：表结构演进统一走 Alembic（docs/design/02 §6），替代 create_all + _auto_migrate。"""
    from pathlib import Path

    from alembic import command
    from alembic.config import Config

    backend_root = Path(__file__).resolve().parents[2]  # src/backend
    alembic_cfg = Config(str(backend_root / "alembic.ini"))
    alembic_cfg.set_main_option("script_location", str(backend_root / "alembic"))
    t0 = time.perf_counter()
    logger.info(f"[DB] Alembic 开始执行（script_location={backend_root / 'alembic'}）…")
    command.upgrade(alembic_cfg, "head")
    logger.info(f"[DB] Alembic upgrade head 完成，耗时 {time.perf_counter() - t0:.2f}s")


def init_db():
    """
    初始化数据库（M0 精简版，docs/design/08 §2 M0 任务 2）：
    1. 创建数据库（如果使用 MySQL）
    2. Alembic upgrade head（R1 baseline 建表；后续演进走新增 revision）
    3. 创建种子数据（用户 / 知识域 / 示例项目）

    整个过程按步骤打耗时日志：启动卡住时能直接看到停在 MySQL 连接、Alembic
    迁移还是种子数据写入，而不是只剩一句“日志初始化完成”后长时间无输出。
    """
    t_all = time.perf_counter()
    logger.info(
        f"[DB] 开始初始化：host={settings.MYSQL_HOST}:{settings.MYSQL_PORT}/"
        f"{settings.MYSQL_DATABASE}，user={settings.MYSQL_USER}")

    # 如果是 MySQL，尝试先连接到服务器创建数据库（如果不存在）
    if settings.DATABASE_URL.startswith("mysql"):
        import pymysql

        t_conn = time.perf_counter()
        try:
            logger.info(
                f"[DB] 连接 MySQL 服务器 {settings.MYSQL_HOST}:{settings.MYSQL_PORT} "
                f"（connect_timeout=5s, read/write_timeout=10s）…")
            conn = pymysql.connect(
                host=settings.MYSQL_HOST,
                port=settings.MYSQL_PORT,
                user=settings.MYSQL_USER,
                password=settings.MYSQL_PASSWORD,
                connect_timeout=5,
                read_timeout=10,
                write_timeout=10,
            )
            logger.info(f"[DB] MySQL 连接成功（{time.perf_counter() - t_conn:.2f}s），"
                        f"检查/创建数据库 {settings.MYSQL_DATABASE}…")
            with conn.cursor() as cursor:
                cursor.execute(f"CREATE DATABASE IF NOT EXISTS {settings.MYSQL_DATABASE} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;")
            conn.commit()
            conn.close()
            logger.info(f"[DB] 数据库就绪（本步耗时 {time.perf_counter() - t_conn:.2f}s）")
        except Exception as e:
            logger.warning(f"[DB] 检查/创建数据库失败（本步耗时 {time.perf_counter() - t_conn:.2f}s），"
                           f"继续尝试 Alembic 迁移：{e}")

    # Alembic 迁移到最新版本
    t_mig = time.perf_counter()
    logger.info("[DB] 开始 Alembic 迁移…")
    _run_migrations()
    logger.info(f"[DB] Alembic 迁移完成（本步耗时 {time.perf_counter() - t_mig:.2f}s）")

    # 创建种子数据
    t_seed = time.perf_counter()
    logger.info("[DB] 开始写入/校验种子数据…")
    db = SessionLocal()
    try:
        _create_initial_data(db)
        logger.info(f"[DB] 初始用户/示例数据就绪（累计 {time.perf_counter() - t_seed:.2f}s）")
        t_domains = time.perf_counter()
        logger.info("[DB] 初始化知识域字典…")
        init_knowledge_domains(db)
        logger.info(f"[DB] 知识域字典完成（{time.perf_counter() - t_domains:.2f}s）")
        # 模块码幂等补种（新增模块码不经 alembic——迁移链已多分支；
        # 只补缺行，不改已有行，授权矩阵不受影响）
        t_modules = time.perf_counter()
        logger.info("[DB] 补种模块码…")
        _ensure_modules(db)
        logger.info(f"[DB] 模块码补种完成（{time.perf_counter() - t_modules:.2f}s）")
        logger.info(f"[DB] 种子数据全部完成（本步耗时 {time.perf_counter() - t_seed:.2f}s）")
    finally:
        db.close()

    logger.info(f"[DB] 数据库初始化完成，总耗时 {time.perf_counter() - t_all:.2f}s")


def _ensure_modules(db):
    """MODULE_SEEDS 里缺哪个码补哪个行（幂等；存量库重启即生效）。"""
    try:
        existing = {m.code for m in db.query(Module).all()}
        missing = [s for s in MODULE_SEEDS if s["code"] not in existing]
        for s in missing:
            db.add(Module(code=s["code"], name=s["name"],
                          description=s["description"],
                          is_default_on=s["is_default_on"],
                          sort_order=s["sort_order"]))
        if missing:
            db.commit()
            print(f"📝 [Modules] 补种新模块码: {[s['code'] for s in missing]}")
    except Exception as e:
        db.rollback()
        print(f"⚠️ [Modules] 补种失败（不影响启动）: {e}")

def _create_initial_data(db):
    """创建初始测试数据"""
    try:
        # 检查是否已有用户
        user_count = db.query(User).count()
        if user_count > 0:
            print(f"ℹ️ [Database] Found {user_count} existing users, skipping initial data creation")
            return
        
        print("📝 [Database] Creating initial test users...")
        
        # 创建测试用户
        test_users = [
            User(
                username="admin",
                hashed_password=bcrypt.hashpw("cbil123456".encode('utf-8'), bcrypt.gensalt()).decode('utf-8'),
                is_active=True
            ),
            User(
                username="testuser",
                hashed_password=bcrypt.hashpw("123456".encode('utf-8'), bcrypt.gensalt()).decode('utf-8'),
                is_active=True
            )
        ]
        
        for user in test_users:
            db.add(user)
        
        db.commit()
        print("✅ [Database] Test users created:")
        print("   - Username: admin, Password: cbil123456")
        print("   - Username: testuser, Password: 123456")
        
        # 创建示例项目
        print("📝 [Database] Creating sample projects...")
        
        admin_user = db.query(User).filter(User.username == "admin").first()
        
        # 获取"通用领域"知识域
        default_domain = db.query(KnowledgeDomain).filter(KnowledgeDomain.name == "通用领域").first()
        domain_id = default_domain.id if default_domain else None
        
        sample_projects = [
            Project(
                name="工业本体示例",
                description="这是一个工业领域的本体模型示例",
                owner_id=admin_user.id,
                domain_id=domain_id,
                graph_data={
                    "nodes": [
                        {
                            "id": "node_1",
                            "type": "default",
                            "position": {"x": 250, "y": 100},
                            "data": {"label": "产品", "type": "Class", "properties": {}},
                            "style": {"background": "#fff", "border": "2px solid #3b82f6", "borderRadius": "8px", "padding": "10px"}
                        },
                        {
                            "id": "node_2",
                            "type": "default",
                            "position": {"x": 100, "y": 250},
                            "data": {"label": "零件", "type": "Class", "properties": {}},
                            "style": {"background": "#fff", "border": "2px solid #3b82f6", "borderRadius": "8px", "padding": "10px"}
                        },
                        {
                            "id": "node_3",
                            "type": "default",
                            "position": {"x": 400, "y": 250},
                            "data": {"label": "工序", "type": "Class", "properties": {}},
                            "style": {"background": "#fff", "border": "2px solid #3b82f6", "borderRadius": "8px", "padding": "10px"}
                        }
                    ],
                    "edges": [
                        {
                            "id": "edge_1",
                            "source": "node_1",
                            "target": "node_2",
                            "type": "smoothstep",
                            "animated": True,
                            "data": {"label": "包含", "relation": "contains"}
                        },
                        {
                            "id": "edge_2",
                            "source": "node_1",
                            "target": "node_3",
                            "type": "smoothstep",
                            "animated": True,
                            "data": {"label": "需要", "relation": "requires"}
                        }
                    ]
                },
                is_published=False
            ),
            Project(
                name="已发布的公共本体",
                description="这是一个已发布的公共本体示例，所有用户都可以在资产中心查看",
                owner_id=admin_user.id,
                domain_id=domain_id,
                graph_data={
                    "nodes": [
                        {
                            "id": "node_1",
                            "type": "default",
                            "position": {"x": 200, "y": 150},
                            "data": {"label": "人员", "type": "Entity", "properties": {}},
                            "style": {"background": "#fff", "border": "2px solid #6366f1", "borderRadius": "8px", "padding": "10px"}
                        },
                        {
                            "id": "node_2",
                            "type": "default",
                            "position": {"x": 400, "y": 150},
                            "data": {"label": "部门", "type": "Entity", "properties": {}},
                            "style": {"background": "#fff", "border": "2px solid #6366f1", "borderRadius": "8px", "padding": "10px"}
                        }
                    ],
                    "edges": [
                        {
                            "id": "edge_1",
                            "source": "node_1",
                            "target": "node_2",
                            "type": "smoothstep",
                            "data": {"label": "属于", "relation": "belongs_to"}
                        }
                    ]
                },
                is_published=True
            )
        ]
        
        for project in sample_projects:
            db.add(project)
        
        db.commit()
        print("✅ [Database] Sample projects created")
        print(f"   - Total projects: {len(sample_projects)}")
        
    except Exception as e:
        print(f"⚠️ [Database] Failed to create initial data: {e}")
        db.rollback()


# M0：_auto_migrate 已删除 —— 表结构演进统一走 Alembic（docs/design/02 §6），
# 旧的 projects.inject_config 手写 ALTER 由 R1 baseline 覆盖。


def _register_graph_rows_listener() -> None:
    """M3-3 双写挂钩（docs/design/02 §4 S1）：监听 Project.graph_data 变更，
    拆写 entities/relations/provenance_records。

    覆盖全部写入点（画布保存/抽取/注入/v1 旧端点/未来新增），无需逐一挂钩。
    行表走独立短会话在 after_flush 写入（S1 blob 为准）：主事务失败仅产生
    行表暂时超前的漂移，由对账脚本检出、下次保存收敛；行表失败不影响 blob 保存。
    """
    from sqlalchemy import event
    from sqlalchemy.orm import Session as SASession

    @event.listens_for(SASession, "before_flush")
    def _on_before_flush(session, flush_context, instances):  # noqa: ANN001
        # 项目删除 → 行表清理（entities.project_id 无 FK，孤儿行需显式删；
        # 放 before_flush：session.deleted 在此处保证可见）+ outbox 下线事件
        deleted_ids = [obj.id for obj in session.deleted if isinstance(obj, Project)]
        if deleted_ids:
            rows = SessionLocal()
            try:
                (rows.query(ProvenanceRecord)
                 .filter(ProvenanceRecord.project_id.in_(deleted_ids),
                         ProvenanceRecord.target_type.in_(["entity", "relation"]))
                 .delete(synchronize_session=False))
                (rows.query(Relation).filter(Relation.project_id.in_(deleted_ids))
                 .delete(synchronize_session=False))
                (rows.query(Entity).filter(Entity.project_id.in_(deleted_ids))
                 .delete(synchronize_session=False))
                for pid in deleted_ids:  # M4：worker-graph 消费 → Neo4j DETACH DELETE（02 §5）
                    rows.add(OutboxEvent(aggregate_type="project", aggregate_id=pid,
                                         event_type="project.deleted",
                                         payload={"project_id": pid}))
                rows.commit()
            except Exception as e:  # noqa: BLE001
                rows.rollback()
                print(f"⚠️ [graph-rows] 项目 {deleted_ids} 行表清理失败: {e}")
            finally:
                rows.close()

    @event.listens_for(SASession, "after_flush")
    def _on_after_flush(session, flush_context):  # noqa: ANN001
        dirty = [obj for obj in list(session.new) + list(session.dirty)
                 if isinstance(obj, Project)
                 and (obj in session.new or session.is_modified(obj, ["graph_data"]))]
        if not dirty:
            return
        from app.services.graph_rows import sync_project_rows

        for proj in dirty:
            rows = SessionLocal()
            try:
                sync_project_rows(rows, proj.id, proj.graph_data)
                # M4（02 §5）：图变更 → outbox 事件，worker-graph 消费同步 Neo4j（同事务写）
                rows.add(OutboxEvent(aggregate_type="project", aggregate_id=proj.id,
                                     event_type="project.graph_rebuilt",
                                     payload={"project_id": proj.id}))
                rows.commit()
            except Exception as e:  # noqa: BLE001 —— 行表失败不影响 blob 写入链路
                rows.rollback()
                print(f"⚠️ [graph-rows] 项目 {proj.id} 行表双写失败（对账脚本可检出）: {e}")
            finally:
                rows.close()


_register_graph_rows_listener()


class OntologyRule(Base):
    """推理规则（蕴含推理期 R1）：IF 主语类-[谓词]->宾语类 THEN 推断[结论谓词]。

    与公理互补：公理=约束（校验违例），规则=产生式（推导新关系）。推导结果一律落
    reasoning_results 且 source='rule'，绝不写回 relations 行表——事实与推理物理分离。
    """
    __tablename__ = "ontology_rules"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False, index=True)
    name = Column(String(128), nullable=False)
    if_subject_class = Column(String(128), nullable=False)
    if_predicate = Column(String(128), nullable=False)
    if_object_class = Column(String(128), nullable=False)
    then_predicate = Column(String(128), nullable=False)
    enabled = Column(Boolean, nullable=False, server_default="1")
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))


class ReasoningResult(Base):
    """推理结果行表（蕴含推理期）：仅存「推导出的」三元组，原始事实不进此表。

    source: 'owlrl'/'rdfs' = owlrl 语义闭包蕴含；'rule' = 自定义规则。同一项目
    每次 run 覆盖式替换（latest-only），batch_id 标记批次。subject/predicate/object
    同存 uri 与 label，便于前端免联查直显。
    """
    __tablename__ = "reasoning_results"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False, index=True)
    batch_id = Column(String(36), nullable=False, index=True)
    source = Column(String(64), nullable=False)
    rule_name = Column(String(128), nullable=True)
    subject_uri = Column(String(512), nullable=False)
    subject_label = Column(String(255), nullable=False, server_default="")
    predicate_uri = Column(String(512), nullable=False)
    predicate_label = Column(String(255), nullable=False, server_default="")
    object_uri = Column(String(512), nullable=False)
    object_label = Column(String(255), nullable=False, server_default="")
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))



# ══════════ O3 方法论产品化（docs/design/09 §2，R19 e9f0a1b2c3d4） ══════════

class CompetencyQuestion(Base):
    """Competency Question 资产（O3-B12）：项目级能力问题列表。

    source: manual=人工录入；evolution=B16 失败问答进化建议批准生成；
    auto=管线自动生成（骨架就绪后的能力问题设计，R23）。
    answer_criteria 为可空 GT 答案要点（配对门控 GT 绝对评分用）。
    """
    __tablename__ = "competency_questions"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False, index=True)
    question = Column(Text, nullable=False)
    answer_criteria = Column(Text, nullable=True)
    source = Column(Enum("manual", "evolution", "auto", name="cq_source"),
                    nullable=False, server_default="manual")
    # SPARQL 模板（SELECT/ASK，平台 URI 约定，R24）：CQ 真执行评测用，可空
    sparql = Column(Text, nullable=True)
    sort_order = Column(Integer, nullable=False, server_default="0")
    enabled = Column(Boolean, nullable=False, server_default="1")
    created_by = Column(Integer, nullable=True)
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))
    updated_at = Column(DateTime, nullable=True)


class CqEvaluation(Base):
    """CQ 评测报告（O3-B12）：抽取后自动（trigger=auto_post_extract）或手动跑 CQ。

    mode: retrieval=检索式跑通率/证据覆盖率（确定性，无 LLM）；gt/llm_judge 留给门控。
    results: [{cq_id, question, answerable, coverage, source_count}]
    """
    __tablename__ = "cq_evaluations"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False, index=True)
    trigger = Column(Enum("manual", "auto_post_extract", "publish_gate", name="cq_eval_trigger"),
                     nullable=False, server_default="manual")
    mode = Column(Enum("retrieval", "llm_judge", "gt", "sparql", "sparql+retrieval",
                       name="cq_eval_mode"),
                  nullable=False, server_default="retrieval")
    baseline_version_id = Column(Integer, nullable=True)
    candidate_version_id = Column(Integer, nullable=True)
    total_cq = Column(Integer, nullable=False, server_default="0")
    answerable_count = Column(Integer, nullable=False, server_default="0")
    coverage_rate = Column(Numeric(4, 3), nullable=False, server_default="0")
    results = Column(JSON, nullable=True)
    created_by = Column(Integer, nullable=True)
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))


class GateEvaluation(Base):
    """发布门控配对评估记录（O3-B14）：候选 vN-cK vs 正式版本的 CQ 配对结论。

    接受条件 = 零硬伤 + 非平局胜场严格更多；记录持久化可审计，幂等重试安全。
    unacceptable_regressions 由门控输入显式声明（发布请求体，缺省 False）。
    """
    __tablename__ = "gate_evaluations"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False, index=True)
    mode = Column(Enum("gt", "llm_judge", name="gate_eval_mode"), nullable=False)
    baseline_version_id = Column(Integer, nullable=True)
    candidate_version_id = Column(Integer, nullable=True)
    wins = Column(Integer, nullable=False, server_default="0")
    ties = Column(Integer, nullable=False, server_default="0")
    losses = Column(Integer, nullable=False, server_default="0")
    hard_failures = Column(Integer, nullable=False, server_default="0")
    unacceptable_regressions = Column(Boolean, nullable=False, server_default="0")
    verdict = Column(Enum("pass", "reject", name="gate_verdict"), nullable=False)
    results = Column(JSON, nullable=True)
    created_by = Column(Integer, nullable=True)
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))


class OntologyImport(Base):
    """导入的标准本体（O3-B17）：OWL/TTL 文件作为项目基础可浏览可引用。

    mappings: 批准的映射/合并 [{import_label, target_label, kind, similarity}]。
    """
    __tablename__ = "ontology_imports"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False, index=True)
    filename = Column(String(255), nullable=False)
    storage_key = Column(String(512), nullable=True)
    format = Column(String(16), nullable=False, server_default="ttl")
    class_count = Column(Integer, nullable=False, server_default="0")
    property_count = Column(Integer, nullable=False, server_default="0")
    mappings = Column(JSON, nullable=True)
    created_by = Column(Integer, nullable=True)
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))


class CopilotSession(Base):
    """Copilot 会话（O5-B22，docs/design/14 §5）：人机协同构建的对话分组。

    kind 语义放消息级（copilot_messages.kind），会话只做分组与模型选择留痕。
    权限挂 resolution 模块（构建域，14 §6）。
    """
    __tablename__ = "copilot_sessions"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False, index=True)
    user_id = Column(Integer, nullable=True, index=True)
    title = Column(String(200), nullable=False, server_default="新会话")
    model_config_id = Column(Integer, nullable=True)
    message_count = Column(Integer, nullable=False, server_default="0")
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))
    updated_at = Column(DateTime, nullable=True,
                        server_default=sa_text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))


class CopilotMessage(Base):
    """Copilot 消息（O5-B22）：role=user/assistant；stages/tool_calls 供回放。

    kind: chat=分析问答；clarify=澄清（S3）；proposal=编辑提案（S2）；
    suggestion=建议卡（S3）；verify=验证报告（S4）。status: ok/failed/stopped。
    """
    __tablename__ = "copilot_messages"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("copilot_sessions.id", ondelete="CASCADE"),
                        nullable=False, index=True)
    project_id = Column(Integer, nullable=False, index=True)
    role = Column(Enum("user", "assistant", name="copilot_message_role"), nullable=False)
    kind = Column(String(16), nullable=False, server_default="chat")
    content = Column(Text, nullable=True)
    stages = Column(JSON, nullable=True)
    tool_calls = Column(JSON, nullable=True)
    # O5-B28：kind=verify 的验证报告 JSON（三段结论 + comparison），会话渲染/回放用
    report = Column(JSON, nullable=True)
    status = Column(String(16), nullable=False, server_default="ok")
    latency_ms = Column(Integer, nullable=True)
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))


class CopilotProposal(Base):
    """Copilot 编辑提案（O5-B25，docs/design/14 §3.1/§5）：提案的持久化与执行状态机。

    status: pending→applied/rejected/expired（并发画布冲突/超期在 apply 时判 expired）。
    base_version 记生成时的画布版本号（OntologyVersion.version_no），执行前比对——
    画布已被别人编辑则拒绝执行并提示刷新（防基于过期画布的破坏性操作）。
    result 留执行结果（version_no/失败原因/自愈原因），审计经 audit_logs 关联 session_id。
    """
    __tablename__ = "copilot_proposals"

    id = Column(Integer, primary_key=True, index=True)
    proposal_id = Column(String(32), nullable=False, unique=True, index=True)
    project_id = Column(Integer, nullable=False, index=True)
    session_id = Column(Integer, ForeignKey("copilot_sessions.id", ondelete="CASCADE"),
                        nullable=True, index=True)
    message_id = Column(Integer, nullable=True)
    kind = Column(String(32), nullable=False)
    targets = Column(JSON, nullable=True)
    diff_preview = Column(JSON, nullable=True)
    impact = Column(JSON, nullable=True)
    llm_reason = Column(Text, nullable=True)
    evidence = Column(JSON, nullable=True)
    risk_tier = Column(String(8), nullable=False, server_default="low")
    status = Column(Enum("pending", "applied", "rejected", "expired",
                         name="copilot_proposal_status"), nullable=False,
                    server_default="pending")
    base_version = Column(Integer, nullable=True)
    result = Column(JSON, nullable=True)
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))
    decided_at = Column(DateTime, nullable=True)


class EvolutionReport(Base):
    """失败问答进化分析报告（O3-B16）：聚合结论 + 物化的审核项 id 留痕。"""
    __tablename__ = "evolution_reports"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, nullable=False, index=True)
    failure_count = Column(Integer, nullable=False, server_default="0")
    window_days = Column(Integer, nullable=False, server_default="7")
    clusters = Column(JSON, nullable=True)
    review_item_ids = Column(JSON, nullable=True)
    created_by = Column(Integer, nullable=True)
    created_at = Column(DateTime, nullable=False, server_default=sa_text("CURRENT_TIMESTAMP"))
