import os
import time

import bcrypt
import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from app.api import (
    auth,
    copilot,
    cqs,
    documents,
    domains,
    env_configs,
    evolution,
    extraction,
    graph_edit,
    graph_view,
    mcp_gateway,
    mcp_tokens,
    model_configs,
    modules,
    ontology,
    ontology_imports,
    pipeline,
    publications,
    qa,
    reasoning,
    reports,
    resolution,
    reviews,
    roles,
    system,
    users,
    versions,
)
from app.core.config import cleanup_dir_if_exceeded, ensure_dirs, settings, start_periodic_cleanup
from app.core.logging import logger
from app.infrastructure.database import SessionLocal, UploadedDocument, User, init_db

logger.info("[startup] 模块导入完成，开始执行启动步骤（后续每步打印耗时）")

# 导入期 Neo4j 客户端已按单例建立连接（见上方 [Neo4j] 日志），这里只确认最终状态
try:
    from app.infrastructure.neo4j_client import neo4j_client as _neo4j_probe
    logger.info("[startup] Neo4j 客户端状态：%s（连接细节见上方 [Neo4j] 日志）",
                "已连接" if _neo4j_probe.driver is not None else "未连接")
except Exception as _neo4j_probe_err:  # noqa: BLE001
    logger.warning(f"[startup] 检查 Neo4j 客户端状态失败：{_neo4j_probe_err}")

# 多 worker 部署（UVICORN_WORKERS>1）时必须由启动命令先跑一次预初始化
# （python -c "from app.infrastructure.database import init_db; init_db()"），
# 再设 PRESTART_INIT_DONE=1 跳过 import 期初始化——否则每个 worker 各自并发
# 跑 alembic/种子数据，空库首次部署会竞态。单机直跑保持默认（=执行）。
_t_db = time.perf_counter()
if os.environ.get("PRESTART_INIT_DONE", "") == "1":
    logger.info("[startup] PRESTART_INIT_DONE=1，跳过 import 期 init_db"
                "（预初始化已由启动命令完成）")
else:
    logger.info("[startup] 开始 init_db（MySQL 连接 + Alembic + 种子数据）…")
    init_db()
    logger.info(f"[startup] init_db 完成，耗时 {time.perf_counter() - _t_db:.2f}s")

_t_dirs = time.perf_counter()
ensure_dirs()
logger.info(f"[startup] ensure_dirs 完成，耗时 {time.perf_counter() - _t_dirs:.2f}s")

for _dir, _label in ((settings.UPLOAD_DIR, "uploads"),
                     (settings.TEMP_DIR, "temp")):
    _t_clean = time.perf_counter()
    logger.info(f"[startup] 开始目录清理检查：{_label}（{_dir}）…")
    cleanup_dir_if_exceeded(_dir, settings.UPLOAD_MAX_SIZE_MB)
    logger.info(f"[startup] 目录清理检查完成：{_label}，耗时 {time.perf_counter() - _t_clean:.2f}s")

_t_dbcheck = time.perf_counter()
logger.info("[startup] 开始旧文档路径迁移 + 用户密码格式检查…")
db = SessionLocal()
try:
    old_docs = db.query(UploadedDocument).filter(
        UploadedDocument.file_path.like("src/backend/uploads/%")
    ).all()
    for doc in old_docs:
        old_path = doc.file_path
        new_path = old_path.replace("src/backend/uploads/", "uploads/", 1)
        if old_path != new_path:
            if os.path.exists(old_path) and not os.path.exists(new_path):
                os.makedirs(os.path.dirname(new_path), exist_ok=True)
                import shutil
                shutil.move(old_path, new_path)
            doc.file_path = new_path
    if old_docs:
        db.commit()

    all_users = db.query(User).all()
    for user in all_users:
        if not user.hashed_password.startswith("$2b$"):
            user.hashed_password = bcrypt.hashpw(user.hashed_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    db.commit()
    logger.info(f"[startup] DB 启动检查完成，耗时 {time.perf_counter() - _t_dbcheck:.2f}s"
                f"（旧文档 {len(old_docs)} 个，用户 {len(all_users)} 个）")
finally:
    db.close()

start_periodic_cleanup(interval_seconds=600)
logger.info("[startup] 后台目录清理线程已启动（每 600s）")


def _start_schedule_poller():
    """定时构建轮询兜底（2026-11-09 测试4 根修）：check_scheduled_pipelines 原本只挂
    celery beat（beat_schedule 每 30s），本地 inline 模式（无 beat 进程）定时构建
    永远不触发。后端自起守护线程同款轮询——触发逻辑先删登记键再抢锁派发，天然
    幂等，beat（docker 部署）与本线程并存也不会重复构建。"""
    import threading as _threading

    def _worker():
        while True:
            try:
                from app.tasks.pipeline_tasks import check_scheduled_pipelines

                check_scheduled_pipelines()
            except Exception:  # noqa: BLE001 —— 轮询失败下轮再试
                pass
            time.sleep(30)

    t = _threading.Thread(target=_worker, daemon=True, name="pipeline-schedule-poller")
    t.start()


_start_schedule_poller()
logger.info("[startup] 定时构建轮询线程已启动；开始创建 FastAPI app 并注册路由…")

app = FastAPI(title="AI 本体构建系统 API", version="1.0.0")


@app.middleware("http")
async def access_log_middleware(request: Request, call_next):
    """请求访问日志：终端 + 按天文件双通道（app/core/logging.py 统一配置）。
    /health 心跳不记录防噪音；异常带堆栈落日志后再抛出。"""
    t0 = time.time()
    try:
        response = await call_next(request)
    except Exception:
        logger.exception(f"{request.method} {request.url.path} -> 500")
        raise
    if request.url.path != "/health":
        cost_ms = int((time.time() - t0) * 1000)
        logger.info(f"{request.method} {request.url.path} -> {response.status_code} ({cost_ms}ms)")
    return response

# M0 安全收口：CORS 由 "*" 改白名单（docs/design/01 §8），来源列表经 .env CORS_ORIGINS 配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# M0：统一错误码响应包络（docs/design/03 §2.3）
from fastapi.responses import JSONResponse  # noqa: E402

from app.core.exceptions import APIError  # noqa: E402


@app.exception_handler(APIError)
async def api_error_handler(request, exc: APIError):
    return JSONResponse(
        status_code=exc.http_status,
        content=exc.to_payload(trace_id=request.headers.get("x-request-id")),
    )

app.include_router(auth.router)
app.include_router(ontology.router)
app.include_router(system.router)
app.include_router(domains.router)
app.include_router(users.router)    # M1：用户管理（admin）
app.include_router(modules.router)  # M1：模块授权矩阵（admin）
app.include_router(roles.router)  # R8：角色配置（模块授权预设，admin）
app.include_router(model_configs.router)  # M2：模型配置
app.include_router(documents.router)  # M3-1：文档上传/秒传/预签名（03 §7）
app.include_router(extraction.router)  # M3-4/5：Schema/Instance 抽取 + 任务进度/SSE/取消（03 §8）
app.include_router(pipeline.router)  # 一键构建管线（新手简化：上传→解析→抽取→自动裁决一条龙）
app.include_router(resolution.router)  # M3-5：实体消解与冲突（03 §9）
app.include_router(reasoning.router)  # 推理期 R1/R3：蕴含推理（owlrl）+ 规则引擎
app.include_router(reviews.router)  # M3-6：审核队列与裁决（03 §11，状态机 pending→claimed→终态）
app.include_router(versions.router)  # M3-6：版本/快照/diff/回滚/时间轴（03 §11，04 §9）
app.include_router(publications.router)  # M3-6：发布与公共区只读（03 §12，04 §10）
app.include_router(graph_edit.router)  # R13：实例探索手动编辑（每次编辑落 manual 版本）
app.include_router(graph_view.router)  # M4：图视图数据契约 + 节点/边详情（03 §13，06 §4）
app.include_router(qa.router)  # M5：本体问答 SSE 流式 + 历史/溯源（03 §15，07 §4）
app.include_router(copilot.router)  # O5-B22：Copilot 人机协同（SSE 会话 + 工具集）
app.include_router(reports.router)  # R8：本体报告/PPT 生成（工具层扩展）
app.include_router(mcp_gateway.router)  # M5：MCP 网关（HTTP Streamable，03 §16，07 §3）
app.include_router(mcp_tokens.router)  # M5：MCP 令牌管理（admin，03 §16）
app.include_router(mcp_tokens.router_self)  # M5+：MCP 令牌自助管理（登录用户限本人令牌）
app.include_router(env_configs.router)  # 环境配置（admin）：中间件连接参数 UI 可改
app.include_router(cqs.router)  # O3-B12：Competency Question 资产 CRUD + 自动评测
app.include_router(evolution.router)  # O3-B16：QA 失败轨迹分析 → 进化建议
app.include_router(ontology_imports.router)  # O3-B17：本体导入 + schema 对齐建议
logger.info("[startup] FastAPI app 创建完成，全部路由已注册")


@app.get('/health')
def get_health():
    return {'status': 'OK'}


if __name__ == '__main__':
    _uvicorn_workers = int(os.environ.get("UVICORN_WORKERS", "1"))
    logger.info(f"[startup] 准备启动 uvicorn：workers={_uvicorn_workers}, port=3001 "
                f"（多 worker 时每个 worker 会再走一遍导入/启动检查）")
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=3001,
        workers=_uvicorn_workers,  # 多 worker 由环境变量控制，默认单进程
        limit_concurrency=100,
        timeout_keep_alive=30,
        # SSE 长连接（pipeline/events 30min 流）会拖住优雅关闭——uvicorn 默认无限等
        # "Waiting for connections to close"，--reload 每次改码都卡 9 分钟（2026-11-08 实测）。
        # 15s 后强制掐断剩余连接；容器重启/热重载不再被流挂死。
        timeout_graceful_shutdown=15,
        log_level="info",
        log_config=None,  # 日志统一走 app/core/logging.py（终端+按天文件），uvicorn 不再自带配置
    )
