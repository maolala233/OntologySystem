import re
import json
import time
import os
import asyncio
import threading
import httpx
from typing import Dict, Any, Iterator, Optional
from openai import OpenAI, AsyncOpenAI
from app.core.config import settings
from app.core.logging import logger
from app.infrastructure.task_manager import TaskCancelledError
from app.services.pipeline_profiler import (
    note_llm_attempt,
    note_llm_chunk,
    note_llm_response,
    note_llm_retry_wait,
)


_PROFILE_SIG_CACHE: Dict[Any, Any] = {}


def _profile_llm_call(func):
    """给 LLMClient 的公开调用方法套上耗时/token 采集（无管线剖析时零开销）。

    用装饰器而非在每个函数体内缩进 try/finally：这四个方法都有多处 return/raise，
    装饰器能保证无论成功、失败还是取消都恰好落一条 LLM 调用记录。
    采集器本身吞掉所有异常，绝不影响真实调用。
    """
    import functools
    import inspect

    call_name = func.__name__

    def _begin(self, args, kwargs):
        from app.services.pipeline_profiler import begin_llm_call, current_profile

        if current_profile() is None:  # 非管线场景：直接跳过签名解析
            return None
        try:
            sig = _PROFILE_SIG_CACHE.get(func)
            if sig is None:
                sig = inspect.signature(func)
                _PROFILE_SIG_CACHE[func] = sig
            bound = sig.bind(self, *args, **kwargs)
            bound.apply_defaults()
            a = bound.arguments
            stream = a.get("stream")
            if stream is None:
                stream = bool(getattr(self, "_default_stream", None) or False)
            return begin_llm_call(
                model=getattr(self, "model", "unknown"),
                stream=bool(stream),
                system_prompt=a.get("system_prompt") or "",
                user_prompt=a.get("user_prompt") or "",
                task_id=a.get("task_id"),
                caller=f"LLMClient.{call_name}",
            )
        except Exception:  # noqa: BLE001 —— 采集失败不影响调用
            return None

    if inspect.iscoroutinefunction(func):
        @functools.wraps(func)
        async def async_wrapper(self, *args, **kwargs):
            from app.services.pipeline_profiler import finish_llm_call

            scope = _begin(self, args, kwargs)
            try:
                result = await func(self, *args, **kwargs)
            except BaseException as e:
                finish_llm_call(scope, e)
                raise
            else:
                finish_llm_call(scope)
                return result

        return async_wrapper

    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        from app.services.pipeline_profiler import finish_llm_call

        scope = _begin(self, args, kwargs)
        try:
            result = func(self, *args, **kwargs)
        except BaseException as e:
            finish_llm_call(scope, e)
            raise
        else:
            finish_llm_call(scope)
            return result

    return wrapper


class LLMEndpointUnreachableError(Exception):
    """模型服务端点级不可达（连接失败/持续超时触发熔断）。

    与单次业务失败不同：这类错误重试毫无意义（服务不在/网络断），必须立即
    中止整段抽取并把原因透传到前端，而不是让 31 个切片各磨 20 分钟重试
    （2026-11-08 项目 265 实测：内网推理服务失联，全部调用 403s 超时×3 层重试，
    管线空转 2 小时+）。"""


class LLMClient:
    def __init__(self, api_key: str = None, base_url: str = None, model: str = None,
                 think_mode: str = None, default_timeout: float = None,
                 default_max_retries: int = None,
                 streaming_enabled: bool = None):
        from app.core.config import settings as _settings

        self.api_key = api_key if api_key is not None else _settings.LLM_API_KEY
        self.model = model if model is not None else _settings.LLM_MODEL_NAME

        raw_url = base_url if base_url is not None else _settings.LLM_BASE_URL
        self.base_url = self._clean_base_url(raw_url)

        # 部分模型（如方舟 glm-5-3-flash）不支持 response_format.type=json_schema，
        # 首次遇到该 400 后降级为 json_object 并记住，避免每次调用都空耗 3 次重试
        self._json_schema_supported = True

        logger.info(f"LLMClient 正在初始化：model={self.model}, base_url={self.base_url}")

        is_external_api = False
        if self.base_url:
            lowercase_url = self.base_url.lower()
            is_external_api = ('openrouter' in lowercase_url or 'api.' in lowercase_url or
                              ('http' in lowercase_url and 'localhost' not in lowercase_url and
                               '127.0.0.1' not in lowercase_url and '.lan' not in lowercase_url))

        client_kwargs = {
            "base_url": self.base_url,
            "api_key": self.api_key if self.api_key else "EMPTY",
            "timeout": 600.0,
        }
        # openai 3.37（httpx2）对自定义 http_client 不套用 SDK timeout——挂住的连接
        # 永远不超时。必须在 httpx 客户端自身上设传输层超时兜底。
        # 300s：流式 QA 每次读间隙远小于它；非流式抽取调用另有 180s per-request 上限
        self._httpx_timeout = httpx.Timeout(300.0, connect=15.0)

        headers = {}
        if self.api_key and self.api_key != "EMPTY":
            # 同时设置 Authorization Bearer 和 apikey header，兼容仓颉等平台
            headers["Authorization"] = f"Bearer {self.api_key}"
            headers["apikey"] = self.api_key
        else:
            headers["Authorization"] = "Bearer EMPTY"
            headers["apikey"] = "EMPTY"
        client_kwargs["default_headers"] = headers

        if is_external_api:
            try:
                client_kwargs["http_client"] = self._create_proxy_http_client()
                logger.info("LLMClient 已启用代理连接")
            except Exception as e:
                logger.warning(f"代理配置失败，使用默认连接：{e}")

        try:
            self.client = OpenAI(**client_kwargs)
            logger.info("LLMClient 同步客户端初始化完成")
        except Exception as e:
            logger.error(f"LLMClient 同步客户端创建失败：{e}")
            raise

        async_client_kwargs = dict(client_kwargs)
        if is_external_api:
            try:
                async_client_kwargs["http_client"] = self._create_proxy_async_http_client()
            except Exception as e:
                logger.warning(f"异步代理配置失败，使用默认连接：{e}")
                async_client_kwargs.pop("http_client", None)
        else:
            async_client_kwargs.pop("http_client", None)

        try:
            self.async_client = AsyncOpenAI(**async_client_kwargs)
            logger.info("LLMClient 异步客户端初始化完成")
        except Exception as e:
            logger.error(f"LLMClient 异步客户端创建失败：{e}")
            self.async_client = None

        # think_mode 可由调用方按模型行 params 覆盖（抽取路径读 disable_think），
        # 不传则回退全局 LLM_THINK_MODE（auto=按模型名关键词自动判断）
        self.think_mode = think_mode or _settings.LLM_THINK_MODE
        # 客户端级超时/重试缺省（模型行 params.llm_timeout / params.max_retries）：
        # call_llm 未显式传时回读——QA/自检/copilot 等所有走本客户端的调用统一受配置管
        self._default_timeout = float(default_timeout) if default_timeout else None
        self._default_max_retries = int(default_max_retries) if default_max_retries else None
        # 流式开关（模型行 params.streaming_enabled 驱动，2026-11-09 接线）：
        # call_llm 未显式传 stream 时回读——配置流式即全链路流式，配置非流式即全链路非流式
        self._default_stream = bool(streaming_enabled) if streaming_enabled is not None else None
        self._is_ollama = self._detect_ollama()
        # ── 端点熔断器（2026-11-08 连不上快速失败）：连续端点级失败（连接错误/超时）
        #    ≥阈值 → 熔断 60s，期间所有调用立即抛 LLMEndpointUnreachableError；
        #    冷却后半开放（放行一次探测），成功即闭合。线程安全（并行切片共享客户端）。
        self._breaker_lock = threading.Lock()
        self._endpoint_fail_streak = 0
        self._breaker_open_until = 0.0

    _BREAKER_THRESHOLD = 2
    _BREAKER_COOLDOWN = 60.0

    @staticmethod
    def _is_connection_error(e: BaseException) -> bool:
        """端点连接失败类（重试无意义）：拒绝/DNS/不可达/建连超时。"""
        if isinstance(e, (ConnectionError, httpx.ConnectError, httpx.ConnectTimeout)):
            return True
        import openai as _openai

        if isinstance(e, _openai.APIConnectionError):
            inner = getattr(e, "__cause__", None)
            return LLMClient._is_connection_error(inner) if inner is not None else True
        s = str(e).lower()
        return any(k in s for k in ("connection refused", "connect timeout",
                                    "connecterror", "getaddrinfo", "unreachable",
                                    "connection reset", "failed to establish"))

    @staticmethod
    def _is_read_timeout(e: BaseException) -> bool:
        """读超时（服务活着但太久没吐字）：单次可重试，连续出现算端点故障。"""
        if isinstance(e, (TimeoutError, httpx.ReadTimeout, httpx.WriteTimeout,
                          httpx.PoolTimeout)):
            return True
        s = str(e).lower()
        return "timed out" in s or "request timed out" in s

    def _breaker_check(self) -> None:
        if time.time() < self._breaker_open_until:
            raise LLMEndpointUnreachableError(
                "模型服务当前不可达（连续多次连接失败已熔断，约 60 秒后自动恢复尝试）")

    def _register_endpoint_failure(self, e: BaseException) -> bool:
        """记录端点级失败；连续 ≥阈值 → 打开熔断。返回是否刚刚打开。"""
        with self._breaker_lock:
            self._endpoint_fail_streak += 1
            if self._endpoint_fail_streak >= self._BREAKER_THRESHOLD:
                self._breaker_open_until = time.time() + self._BREAKER_COOLDOWN
                return True
        return False

    def _register_endpoint_success(self) -> None:
        with self._breaker_lock:
            self._endpoint_fail_streak = 0
            self._breaker_open_until = 0.0

    def _detect_ollama(self) -> bool:
        if not self.base_url:
            return False
        return ":11434" in self.base_url or "ollama" in self.base_url.lower()

    def _should_disable_think(self) -> bool:
        if self.think_mode == "disabled":
            return True
        if self.think_mode == "enabled":
            return False
        model_lower = self.model.lower()
        thinking_keywords = ["qwen3", "gemma", "granite4", "deepseek-r1", "think"]
        return any(kw in model_lower for kw in thinking_keywords)

    def _create_proxy_http_client(self):
        import httpx
        from urllib.parse import urlparse

        # M0 安全收口：删除 openrouter 硬编码代理 127.0.0.1:7890（docs/design/01 §8），
        # 代理一律按需读环境变量 HTTP_PROXY/HTTPS_PROXY
        http_proxy = os.environ.get('http_proxy') or os.environ.get('HTTP_PROXY')
        https_proxy = os.environ.get('https_proxy') or os.environ.get('HTTPS_PROXY')
        proxy_to_use = https_proxy or http_proxy

        if proxy_to_use:
            if 'socks' in proxy_to_use.lower():
                try:
                    from httpx_socks import SyncProxyTransport
                    parsed = urlparse(proxy_to_use)
                    if parsed.scheme.startswith('socks'):
                        return httpx.Client(transport=SyncProxyTransport.from_url(proxy_to_use),
                                   timeout=self._httpx_timeout)
                except ImportError:
                    logger.warning("httpx_socks not installed for SOCKS proxy support.")
                    return httpx.Client(timeout=self._httpx_timeout)
                except Exception as e:
                    logger.warning(f"Failed to create proxy client: {e}. Falling back to no proxy.")
                    return httpx.Client(timeout=self._httpx_timeout)
            else:
                try:
                    return httpx.Client(proxy=proxy_to_use, timeout=self._httpx_timeout)
                except ValueError as e:
                    logger.warning(f"Invalid proxy URL format: {e}. Falling back to no proxy.")
                    return httpx.Client(timeout=self._httpx_timeout)
                except Exception as e:
                    logger.warning(f"Failed to create HTTP proxy client: {e}. Falling back to no proxy.")
                    return httpx.Client(timeout=self._httpx_timeout)

        return httpx.Client(timeout=self._httpx_timeout)

    def _create_proxy_async_http_client(self):
        import httpx
        from urllib.parse import urlparse

        # M0 安全收口：同上，删除 openrouter 硬编码代理
        http_proxy = os.environ.get('http_proxy') or os.environ.get('HTTP_PROXY')
        https_proxy = os.environ.get('https_proxy') or os.environ.get('HTTPS_PROXY')
        proxy_to_use = https_proxy or http_proxy

        if proxy_to_use:
            if 'socks' in proxy_to_use.lower():
                try:
                    from httpx_socks import AsyncProxyTransport
                    parsed = urlparse(proxy_to_use)
                    if parsed.scheme.startswith('socks'):
                        return httpx.AsyncClient(transport=AsyncProxyTransport.from_url(proxy_to_use),
                                         timeout=self._httpx_timeout)
                except ImportError:
                    logger.warning("httpx_socks not installed for SOCKS proxy support.")
                    return httpx.AsyncClient(timeout=self._httpx_timeout)
                except Exception as e:
                    logger.warning(f"Failed to create async proxy client: {e}. Falling back to no proxy.")
                    return httpx.AsyncClient(timeout=self._httpx_timeout)
            else:
                try:
                    return httpx.AsyncClient(proxy=proxy_to_use)
                except ValueError as e:
                    logger.warning(f"Invalid proxy URL format: {e}. Falling back to no proxy.")
                    return httpx.AsyncClient(timeout=self._httpx_timeout)
                except Exception as e:
                    logger.warning(f"Failed to create async HTTP proxy client: {e}. Falling back to no proxy.")
                    return httpx.AsyncClient(timeout=self._httpx_timeout)

        return httpx.AsyncClient(timeout=self._httpx_timeout)

    def _clean_base_url(self, url: str) -> str:
        if not url:
            return ""
        url = url.strip()
        if url.endswith("/"):
            url = url[:-1]
        if url.endswith("/chat/completions"):
            url = url.replace("/chat/completions", "")
        if url.endswith("/completions"):
            url = url.replace("/completions", "")
        return url

    def _build_api_kwargs(self, system_prompt: str, user_prompt: str, stream: bool = True,
                          timeout: Optional[float] = None, json_schema: Optional[Dict[str, Any]] = None,
                          max_tokens: int = 16000) -> dict:
        api_kwargs = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "temperature": 0.1,
            "stream": stream,
            "max_tokens": max_tokens,
            "stop": ["</s>", "\n\n\n"]
        }
        if self._should_disable_think():
            # 按平台方言关思考：方舟用 thinking 结构体（chat_template_kwargs 是
            # vLLM 方言，方舟会静默忽略→思考照开→长 prompt 缝合调用稳超 330s 硬闸）；
            # ollama 用 reasoning_effort；其余平台用 chat_template_kwargs（Qwen3.5 等）
            if self._is_ollama:
                api_kwargs["extra_body"] = {"reasoning_effort": "none"}
            elif "volces.com" in (self.base_url or "").lower():
                api_kwargs["extra_body"] = {"thinking": {"type": "disabled"}}
            else:
                api_kwargs["extra_body"] = {"chat_template_kwargs": {"enable_thinking": False}}

        if timeout is not None:
            api_kwargs["timeout"] = timeout

        if json_schema and self._json_schema_supported:
            logger.info(f"[LLM] 使用 json_schema 参数约束输出格式")
            api_kwargs["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": "output_schema",
                    "schema": json_schema,
                    "strict": True
                }
            }
        else:
            requires_json = (
                "json" in system_prompt.lower() or
                "json" in user_prompt.lower() or
                "JSON" in system_prompt or
                "JSON" in user_prompt or
                "返回 json" in system_prompt.lower() or
                "返回 json" in user_prompt.lower() or
                "输出 json" in system_prompt.lower() or
                "输出 json" in user_prompt.lower() or
                "parse" in system_prompt.lower() and "structure" in system_prompt.lower()
            )
            if requires_json:
                logger.info(f"[LLM] 检测到 JSON 输出要求，使用 json_object 格式")
                api_kwargs["response_format"] = {"type": "json_object"}
                # json_object 不承载 Schema：契约必须以文本进 prompt，否则模型只能
                # 自行发明输出键名（如 instances/name），校验层拿到空壳实体
                if json_schema:
                    api_kwargs["messages"][0]["content"] += (
                        "\n\n【输出 JSON Schema（顶层键与字段名必须严格一致）】\n"
                        + json.dumps(json_schema, ensure_ascii=False))

        return api_kwargs

    @staticmethod
    def _is_json_schema_unsupported(err: Exception) -> bool:
        msg = str(err).lower()
        return "json_schema" in msg and ("not supported" in msg or "invalidparameter" in msg)

    def _create_with_hard_gate(self, api_kwargs: Dict[str, Any], timeout: Optional[float]):
        """create 调用的硬超时闸（2026-11-05）：自定义 http_client 下 openai SDK 的
        timeout 参数失效（openai 3.37/httpx2 不套用），模型挂起时连接无限阻塞——
        抽取/裁决任务卡死、"停止"按钮永远等不到分块检查点（248/252 实测）。
        守护线程发起调用 + join(hard) 硬闸：超时弃车（线程自然消亡，不 join 回收），
        上层重试循环接手（重试耗尽走正常失败路径）。"""
        hard = (timeout or 300.0) + 30
        box: Dict[str, Any] = {}

        def _run():
            try:
                box["r"] = self.client.chat.completions.create(**api_kwargs)
            except BaseException as e:  # noqa: BLE001 —— 原样回传上层分类处理
                box["e"] = e

        th = threading.Thread(target=_run, daemon=True, name="llm-hardgate")
        th.start()
        th.join(hard)
        if "r" in box:
            return box["r"]
        if "e" in box:
            raise box["e"]
        raise TimeoutError(f"LLM 调用硬超时（{hard:.0f}s 无任何响应）")

    @_profile_llm_call
    def call_llm(self, system_prompt: str, user_prompt: str, max_retries: Optional[int] = None,
                 stream: Optional[bool] = None, timeout: Optional[float] = None,
                 task_id: Optional[str] = None,
                 json_schema: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        if stream is None:
            stream = bool(getattr(self, "_default_stream", None) or False)
        from app.infrastructure.task_manager import task_manager
        # 客户端级缺省（构造时来自模型行 params，见 qa._build_llm / 抽取路径）：
        # 调用点未显式传 timeout/max_retries 时兜底——此前 12+ 个未传的调用点
        # （自检/copilot/进化/门控…）一律落到 330s 硬闸+3 重试的隐式默认
        # （2026-11-08 全局接线）
        if timeout is None:
            timeout = getattr(self, '_default_timeout', None)
        if max_retries is None:
            max_retries = getattr(self, '_default_max_retries', None) or 3
        model_name = getattr(self, 'model', 'unknown-model')
        call_start_time = time.time()
        timeout_str = f"{timeout}s" if timeout else "default"
        logger.info(f"正在发起 LLM 调用：model={model_name}, stream={stream}, timeout={timeout_str}, json_schema={json_schema is not None}")
        logger.info(f"[LLM] 请求内容长度：system_prompt={len(system_prompt)} 字符，user_prompt={len(user_prompt)} 字符")
        if task_id:
            logger.info(f"[LLM] 任务 ID: {task_id}，将在流式响应中检查取消状态")

        for attempt in range(max_retries):
            note_llm_attempt()
            self._breaker_check()
            response = None
            try:
                api_kwargs = self._build_api_kwargs(system_prompt, user_prompt, stream, timeout, json_schema)
                response = self._create_with_hard_gate(api_kwargs, timeout)
                if not stream:
                    note_llm_response(response)

                if stream:
                    logger.info(f"[LLM] 开始接收流式响应...")
                    stream_start = time.time()
                    full_content = ""
                    chunk_count = 0
                    finish_reason = None
                    stream_timeout = timeout if timeout is not None else 120.0
                    try:
                        for chunk in response:
                            if task_id and task_manager.is_cancelled(task_id):
                                logger.info(f"[LLM] 检测到任务取消，中断流式响应 (已接收 {chunk_count} 个 chunk)")
                                if hasattr(response, 'close'):
                                    try:
                                        response.close()
                                    except Exception:
                                        pass
                                raise TaskCancelledError(f"Task {task_id} was cancelled during streaming")

                            note_llm_chunk(chunk)
                            elapsed_time = time.time() - stream_start
                            if elapsed_time > stream_timeout:
                                logger.error(f"LLM 调用超时（timeout={stream_timeout}s），中断流式响应")
                                if hasattr(response, 'close'):
                                    try:
                                        response.close()
                                    except Exception:
                                        pass
                                raise TimeoutError(f"LLM streaming response timeout after {elapsed_time:.2f}s")

                            if chunk.choices and chunk.choices[0].delta:
                                if chunk.choices[0].finish_reason:
                                    finish_reason = chunk.choices[0].finish_reason
                                    logger.info(f"[LLM] 流式响应 finish_reason: {finish_reason}")

                                chunk_count += 1
                                if chunk.choices[0].delta.content:
                                    full_content += chunk.choices[0].delta.content
                                delta = chunk.choices[0].delta
                                if hasattr(delta, 'reasoning_content') and delta.reasoning_content:
                                    full_content += delta.reasoning_content

                                if len(full_content) > 60000:
                                    if hasattr(response, 'close'):
                                        try:
                                            response.close()
                                        except Exception:
                                            pass
                                    raise TimeoutError(
                                        f"LLM 流式响应超长（>{len(full_content)} 字符），疑似失控生成")
                                if chunk_count % 50 == 0:
                                    logger.info(f"[LLM] 已接收 {chunk_count} 个 chunk, 当前内容长度={len(full_content)} 字符，耗时={time.time()-stream_start:.2f}s")

                        logger.info(f"[LLM] 流式响应完成，总内容长度={len(full_content)} 字符，总耗时={time.time()-stream_start:.2f}s, finish_reason={finish_reason}")

                        if finish_reason == 'length':
                            logger.info(f"[LLM] 检测到输出被截断（finish_reason=length），启动自动续写机制...")
                            continued_content = self._continue_generation(
                                system_prompt=system_prompt, user_prompt=user_prompt,
                                partial_content=full_content, timeout=timeout,
                                task_id=task_id, json_schema=json_schema,
                            )
                            full_content += continued_content
                            logger.info(f"[LLM] 自动续写完成，追加内容长度={len(continued_content)} 字符，总长度={len(full_content)} 字符")

                        self._register_endpoint_success()
                        return self._repair_truncated_json(full_content)
                    except GeneratorExit:
                        if response and hasattr(response, 'close'):
                            try:
                                response.close()
                            except Exception:
                                pass
                        raise
                else:
                    if not response or not response.choices or len(response.choices) == 0:
                        raise ValueError("模型返回空响应（无 choices），按失败处理以触发重试")
                    message_content = response.choices[0].message.content
                    finish_reason = response.choices[0].finish_reason

                    if message_content is None or not str(message_content).strip():
                        # 空壳响应（限流/拥堵时段方舟秒回空）：抛错走重试，绝不静默
                        # 返回空结构——那会把"模型没干活"伪装成"抽出来 0 条"
                        raise ValueError(f"模型返回空响应（finish_reason={finish_reason}）")

                    logger.info(f"[LLM] 非流式响应，内容长度={len(message_content)} 字符，finish_reason={finish_reason}")

                    if finish_reason == 'length':
                        logger.info(f"[LLM] 检测到输出被截断（finish_reason=length），启动自动续写机制...")
                        continued_content = self._continue_generation(
                            system_prompt=system_prompt, user_prompt=user_prompt,
                            partial_content=message_content, timeout=timeout,
                            task_id=task_id, json_schema=json_schema,
                        )
                        message_content += continued_content
                        logger.info(f"[LLM] 自动续写完成，追加内容长度={len(continued_content)} 字符，总长度={len(message_content)} 字符")

                    self._register_endpoint_success()
                    return self._repair_truncated_json(message_content)

            except TaskCancelledError as e:
                logger.info(f"任务被取消，停止重试：{e}")
                if response and hasattr(response, 'close'):
                    try:
                        response.close()
                    except Exception:
                        pass
                raise
            except TimeoutError as e:
                # 硬闸超时=服务挂起，属端点级失败：连续出现即熔断并转不可达异常，
                # 让上层快速失败而不是把重试预算烧在一个已死的服务上
                opened = self._register_endpoint_failure(e)
                if opened:
                    raise LLMEndpointUnreachableError(
                        f"模型服务持续无响应（连续调用硬超时）：{e}") from e
                if response and hasattr(response, 'close'):
                    try:
                        response.close()
                    except Exception:
                        pass
                raise
            except Exception as e:
                if response and hasattr(response, 'close'):
                    try:
                        response.close()
                    except Exception:
                        pass
                # 连接类失败（拒绝/DNS/不可达）：重试毫无意义，立即转不可达异常
                # 中止本调用；连续两次打开熔断，后续调用秒败（2026-11-08 根修）
                if self._is_connection_error(e):
                    opened = self._register_endpoint_failure(e)
                    logger.error(f"模型服务连接失败（熔断{'已' if opened else '未'}打开，"
                                 f"连续失败 {self._endpoint_fail_streak} 次）：{e}")
                    raise LLMEndpointUnreachableError(f"模型服务连接失败：{e}") from e
                if self._is_read_timeout(e) and self._register_endpoint_failure(e):
                    raise LLMEndpointUnreachableError(
                        f"模型服务持续超时（连续多次无响应）：{e}") from e
                err_msg = str(e).lower()
                if self._is_json_schema_unsupported(e):
                    self._json_schema_supported = False
                    logger.warning(f"[LLM] 当前模型不支持 json_schema 约束输出，本次会话降级为 json_object 模式重试: {e}")
                    continue
                if "429" in err_msg or "rate limit" in err_msg:
                    wait_time = (attempt + 1) * 10
                    logger.warning(f"触发 API 限流，正在进行第 {attempt+1} 次重试，等待 {wait_time} 秒...")
                    note_llm_retry_wait(wait_time)
                    time.sleep(wait_time)
                elif attempt < max_retries - 1:
                    logger.warning(f"LLM 调用失败：{e}，正在重试... (尝试 {attempt+1}/{max_retries}, 已耗时={time.time()-call_start_time:.2f}s)")
                    note_llm_retry_wait(2)
                    time.sleep(2)
                else:
                    total_time = time.time() - call_start_time
                    logger.error(f"LLM 调用在 {max_retries} 次尝试后仍然失败，总耗时={total_time:.2f}s: {str(e)}")
                    raise Exception(f"LLM 调用在 {max_retries} 次尝试后仍然失败，总耗时={total_time:.2f}s: {str(e)}")

    @_profile_llm_call
    async def async_call_llm(self, system_prompt: str, user_prompt: str, max_retries: int = 3,
                             stream: Optional[bool] = None, timeout: Optional[float] = None,
                             task_id: Optional[str] = None,
                             json_schema: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        if stream is None:
            stream = bool(getattr(self, "_default_stream", None) or False)
        from app.infrastructure.task_manager import task_manager
        model_name = getattr(self, 'model', 'unknown-model')
        call_start_time = time.time()
        timeout_str = f"{timeout}s" if timeout else "default"
        logger.info(f"正在发起异步 LLM 调用：model={model_name}, stream={stream}, timeout={timeout_str}, json_schema={json_schema is not None}")
        logger.info(f"[AsyncLLM] 请求内容长度：system_prompt={len(system_prompt)} 字符，user_prompt={len(user_prompt)} 字符")
        if task_id:
            logger.info(f"[AsyncLLM] 任务 ID: {task_id}，将在流式响应中检查取消状态")

        if not self.async_client:
            logger.warning("[AsyncLLM] 异步客户端不可用，回退到同步调用（在线程池中执行）")
            return await asyncio.get_event_loop().run_in_executor(
                None, lambda: self.call_llm(system_prompt, user_prompt, max_retries, stream, timeout, task_id, json_schema)
            )

        for attempt in range(max_retries):
            note_llm_attempt()
            self._breaker_check()
            response = None
            try:
                api_kwargs = self._build_api_kwargs(system_prompt, user_prompt, stream, timeout, json_schema)
                response = await self.async_client.chat.completions.create(**api_kwargs)
                if not stream:
                    note_llm_response(response)

                if stream:
                    logger.info(f"[AsyncLLM] 开始接收流式响应...")
                    stream_start = time.time()
                    full_content = ""
                    chunk_count = 0
                    finish_reason = None
                    stream_timeout = timeout if timeout is not None else 120.0
                    try:
                        async for chunk in response:
                            if task_id and task_manager.is_cancelled(task_id):
                                logger.info(f"[AsyncLLM] 检测到任务取消，中断流式响应 (已接收 {chunk_count} 个 chunk)")
                                if hasattr(response, 'aclose'):
                                    try:
                                        await response.aclose()
                                    except Exception:
                                        pass
                                raise TaskCancelledError(f"Task {task_id} was cancelled during streaming")

                            note_llm_chunk(chunk)
                            elapsed_time = time.time() - stream_start
                            if elapsed_time > stream_timeout:
                                logger.error(f"[AsyncLLM] 调用超时（timeout={stream_timeout}s），中断流式响应")
                                if hasattr(response, 'aclose'):
                                    try:
                                        await response.aclose()
                                    except Exception:
                                        pass
                                raise TimeoutError(f"LLM streaming response timeout after {elapsed_time:.2f}s")

                            if chunk.choices and chunk.choices[0].delta:
                                if chunk.choices[0].finish_reason:
                                    finish_reason = chunk.choices[0].finish_reason
                                    logger.info(f"[AsyncLLM] 流式响应 finish_reason: {finish_reason}")

                                chunk_count += 1
                                if chunk.choices[0].delta.content:
                                    full_content += chunk.choices[0].delta.content
                                delta = chunk.choices[0].delta
                                if hasattr(delta, 'reasoning_content') and delta.reasoning_content:
                                    full_content += delta.reasoning_content

                                if len(full_content) > 60000:
                                    if hasattr(response, 'close'):
                                        try:
                                            response.close()
                                        except Exception:
                                            pass
                                    raise TimeoutError(
                                        f"LLM 流式响应超长（>{len(full_content)} 字符），疑似失控生成")
                                if chunk_count % 50 == 0:
                                    logger.info(f"[AsyncLLM] 已接收 {chunk_count} 个 chunk, 当前内容长度={len(full_content)} 字符，耗时={time.time()-stream_start:.2f}s")

                        logger.info(f"[AsyncLLM] 流式响应完成，总内容长度={len(full_content)} 字符，总耗时={time.time()-stream_start:.2f}s, finish_reason={finish_reason}")

                        if finish_reason == 'length':
                            logger.info(f"[AsyncLLM] 检测到输出被截断（finish_reason=length），启动自动续写机制...")
                            continued_content = await self._async_continue_generation(
                                system_prompt=system_prompt, user_prompt=user_prompt,
                                partial_content=full_content, timeout=timeout,
                                task_id=task_id, json_schema=json_schema,
                            )
                            full_content += continued_content
                            logger.info(f"[AsyncLLM] 自动续写完成，追加内容长度={len(continued_content)} 字符，总长度={len(full_content)} 字符")

                        self._register_endpoint_success()
                        return self._repair_truncated_json(full_content)
                    except GeneratorExit:
                        if response and hasattr(response, 'aclose'):
                            try:
                                await response.aclose()
                            except Exception:
                                pass
                        raise
                else:
                    if not response or not response.choices or len(response.choices) == 0:
                        raise ValueError("模型返回空响应（无 choices），按失败处理以触发重试")
                    message_content = response.choices[0].message.content
                    finish_reason = response.choices[0].finish_reason

                    if message_content is None or not str(message_content).strip():
                        raise ValueError(f"模型返回空响应（finish_reason={finish_reason}）")

                    logger.info(f"[AsyncLLM] 非流式响应，内容长度={len(message_content)} 字符，finish_reason={finish_reason}")

                    if finish_reason == 'length':
                        logger.info(f"[AsyncLLM] 检测到输出被截断（finish_reason=length），启动自动续写机制...")
                        continued_content = await self._async_continue_generation(
                            system_prompt=system_prompt, user_prompt=user_prompt,
                            partial_content=message_content, timeout=timeout,
                            task_id=task_id, json_schema=json_schema,
                        )
                        message_content += continued_content
                        logger.info(f"[AsyncLLM] 自动续写完成，追加内容长度={len(continued_content)} 字符，总长度={len(message_content)} 字符")

                    self._register_endpoint_success()
                    return self._repair_truncated_json(message_content)

            except TaskCancelledError as e:
                logger.info(f"[AsyncLLM] 任务被取消，停止重试：{e}")
                if response and hasattr(response, 'aclose'):
                    try:
                        await response.aclose()
                    except Exception:
                        pass
                raise
            except TimeoutError as e:
                opened = self._register_endpoint_failure(e)
                if opened:
                    raise LLMEndpointUnreachableError(
                        f"模型服务持续无响应（连续调用硬超时）：{e}") from e
                if response and hasattr(response, 'aclose'):
                    try:
                        await response.aclose()
                    except Exception:
                        pass
                raise
            except Exception as e:
                if response and hasattr(response, 'aclose'):
                    try:
                        await response.aclose()
                    except Exception:
                        pass
                if self._is_connection_error(e):
                    opened = self._register_endpoint_failure(e)
                    logger.error(f"模型服务连接失败（熔断{'已' if opened else '未'}打开，"
                                 f"连续失败 {self._endpoint_fail_streak} 次）：{e}")
                    raise LLMEndpointUnreachableError(f"模型服务连接失败：{e}") from e
                if self._is_read_timeout(e) and self._register_endpoint_failure(e):
                    raise LLMEndpointUnreachableError(
                        f"模型服务持续超时（连续多次无响应）：{e}") from e
                err_msg = str(e).lower()
                if self._is_json_schema_unsupported(e):
                    self._json_schema_supported = False
                    logger.warning(f"[LLM] 当前模型不支持 json_schema 约束输出，本次会话降级为 json_object 模式重试: {e}")
                    continue
                if "429" in err_msg or "rate limit" in err_msg:
                    wait_time = (attempt + 1) * 10
                    logger.warning(f"[AsyncLLM] 触发 API 限流，正在进行第 {attempt+1} 次重试，等待 {wait_time} 秒...")
                    note_llm_retry_wait(wait_time)
                    await asyncio.sleep(wait_time)
                elif attempt < max_retries - 1:
                    logger.warning(f"[AsyncLLM] 调用失败：{e}，正在重试... (尝试 {attempt+1}/{max_retries}, 已耗时={time.time()-call_start_time:.2f}s)")
                    note_llm_retry_wait(2)
                    await asyncio.sleep(2)
                else:
                    total_time = time.time() - call_start_time
                    logger.error(f"[AsyncLLM] 调用在 {max_retries} 次尝试后仍然失败，总耗时={total_time:.2f}s: {str(e)}")
                    raise Exception(f"LLM 调用在 {max_retries} 次尝试后仍然失败，总耗时={total_time:.2f}s: {str(e)}")

    def _repair_truncated_json(self, json_str: str) -> Dict[str, Any]:
        if not json_str:
            return {"classes": [], "instances": [], "object_types": [], "link_types": [], "links": []}

        clean = json_str.strip()
        clean = re.sub(r'^```json\s*', '', clean, flags=re.MULTILINE)
        clean = re.sub(r'^```\s*', '', clean, flags=re.MULTILINE)
        clean = re.sub(r'```$', '', clean, flags=re.MULTILINE)
        clean = clean.strip()

        if clean.lower().startswith(('hello', 'hi ', 'i ', 'the ', 'this ', 'that ', 'yes', 'no', 'ok', 'sure', 'sorry', 'cannot', 'unable')):
            logger.warning(f"检测到非 JSON 内容：{clean[:100]}...，返回默认结构")
            return {'classes': [], 'instances': [], 'object_types': [], 'link_types': [], 'links': []}

        try:
            return json.loads(clean)
        except json.JSONDecodeError as e:
            logger.warning(f"检测到 JSON 解析错误，原始内容：{clean[:200]}..., 正在尝试自动修复...")
            logger.debug(f"JSON 解析错误详情：{e}")

            # ★ O4 公理建议通道：模型在 json_object 降级模式下可能先输出大段分析
            # 文字再给 {"suggestions":[...]}（走查实测），按键定位平衡对象直接提取。
            # ★ S9 规则挖掘通道同理（{"rules":[...]}）。
            # 抽取链路响应不含这些键，此分支对其零影响。
            for _key in ('"suggestions"', '"rules"'):
                if _key not in clean:
                    continue
                key_at = clean.rfind(_key)
                brace_at = clean.rfind('{', 0, key_at)
                if brace_at == -1:
                    continue
                depth = 0
                parsed = None
                for i in range(brace_at, len(clean)):
                    if clean[i] == '{':
                        depth += 1
                    elif clean[i] == '}':
                        depth -= 1
                        if depth == 0:
                            try:
                                parsed = json.loads(clean[brace_at:i + 1])
                            except json.JSONDecodeError:
                                parsed = None
                            break
                if isinstance(parsed, dict) and isinstance(parsed.get(_key.strip('"')), list):
                    logger.info(f"[JSON 修复成功] 方法：{_key.strip(chr(34))} 键定位，提取 {i + 1 - brace_at} 字符")
                    return parsed

            # ★ 优先尝试：转义字符串内的控制字符（LLM 输出最常见的"结构完整但非法"问题）
            try:
                escaped_json = self._escape_control_chars_in_json(clean)
                if escaped_json != clean:
                    parsed = json.loads(escaped_json)
                    for key in ["classes", "object_types"]:
                        if key not in parsed:
                            parsed[key] = []
                    for key in ["instances", "link_types", "links"]:
                        if key not in parsed:
                            parsed[key] = []
                    logger.info(f"[JSON 修复成功] 方法：转义字符串内控制字符，原始 {len(clean)} 字符 → 修复后 {len(escaped_json)} 字符")
                    return parsed
            except Exception as esc_e:
                logger.debug(f"[JSON 修复] 转义控制字符失败：{esc_e}")

            fix_attempts = 0
            try:
                fix_attempts += 1
                fixed_json = self._try_fix_json_structure(clean)
                if fixed_json:
                    logger.debug(f"[JSON 修复尝试 {fix_attempts}] 结构修复：{len(fixed_json)} 字符")
                    parsed = json.loads(fixed_json)
                    for key in ["classes", "object_types"]:
                        if key not in parsed:
                            parsed[key] = []
                    for key in ["instances", "link_types", "links"]:
                        if key not in parsed:
                            parsed[key] = []
                    logger.info(f"[JSON 修复成功] 方法：结构修复")
                    return parsed
            except Exception as e:
                logger.debug(f"[JSON 修复尝试 {fix_attempts}] 结构修复失败：{e}")

            fix_attempts += 1
            json_start = clean.find('{')
            if json_start != -1:
                bracket_count = 0
                for i, char in enumerate(clean[json_start:], json_start):
                    if char == '{':
                        bracket_count += 1
                    elif char == '}':
                        bracket_count -= 1
                        if bracket_count == 0:
                            possible_json = clean[json_start:i+1]
                            try:
                                parsed = json.loads(possible_json)
                                for key in ["classes", "object_types"]:
                                    if key not in parsed:
                                        parsed[key] = []
                                for key in ["instances", "link_types", "links"]:
                                    if key not in parsed:
                                        parsed[key] = []
                                logger.info(f"[JSON 修复成功] 方法：括号平衡法，提取 {len(possible_json)} 字符")
                                return parsed
                            except json.JSONDecodeError as je:
                                logger.debug(f"[JSON 修复尝试 {fix_attempts}] 括号平衡法失败：{je}")
                            break

            fix_attempts += 1
            last_object_end = clean.rfind("},")
            if last_object_end != -1:
                fixed_json = clean[:last_object_end + 1] + "]}"
                try:
                    parsed = json.loads(fixed_json)
                    for key in ["classes", "object_types"]:
                        if key not in parsed:
                            parsed[key] = []
                    for key in ["instances", "link_types", "links"]:
                        if key not in parsed:
                            parsed[key] = []
                    logger.info(f"[JSON 修复成功] 方法：截断到最后对象，提取 {len(fixed_json)} 字符")
                    return parsed
                except json.JSONDecodeError as je:
                    logger.debug(f"[JSON 修复尝试 {fix_attempts}] 截断法失败：{je}")

            fix_attempts += 1
            last_bracket = clean.rfind("}")
            if last_bracket != -1:
                fixed_json = clean[:last_bracket + 1] + "]}"
                try:
                    parsed = json.loads(fixed_json)
                    for key in ["classes", "object_types"]:
                        if key not in parsed:
                            parsed[key] = []
                    for key in ["instances", "link_types", "links"]:
                        if key not in parsed:
                            parsed[key] = []
                    logger.info(f"[JSON 修复成功] 方法：最后括号截断，提取 {len(fixed_json)} 字符")
                    return parsed
                except json.JSONDecodeError as je:
                    logger.debug(f"[JSON 修复尝试 {fix_attempts}] 最后括号截断失败：{je}")

            fix_attempts += 1
            try:
                cleaned = re.sub(r',\s*}', '}', clean)
                cleaned = re.sub(r',\s*]', ']', cleaned)
                parsed = json.loads(cleaned)
                for key in ["classes", "object_types"]:
                    if key not in parsed:
                        parsed[key] = []
                for key in ["instances", "link_types", "links"]:
                    if key not in parsed:
                        parsed[key] = []
                logger.info(f"[JSON 修复成功] 方法：逗号修复，提取 {len(cleaned)} 字符")
                return parsed
            except json.JSONDecodeError as je:
                logger.debug(f"[JSON 修复尝试 {fix_attempts}] 逗号修复失败：{je}")

            logger.error(f"JSON 修复失败 (共尝试 {fix_attempts} 种方法)，返回默认结构，原始内容前 200 字符：{clean[:200]}...")
            return {"classes": [], "instances": [], "object_types": [], "link_types": [], "links": []}

    def _clean_continued_content(self, content: str) -> str:
        content = re.sub(r'^```(?:json)?\s*', '', content.lstrip())
        content = re.sub(r'^好的.*?[:：]\s*', '', content, flags=re.IGNORECASE)
        content = re.sub(r'^[^\{\[\"\'\w]*sure.*?[:：]\s*', '', content, flags=re.IGNORECASE)
        content = re.sub(r'^[^\{\[\"\'\w]*here.*?is.*?the.*?continuation.*?[:：]\s*', '', content, flags=re.IGNORECASE)
        content = re.sub(r'^[^\{\[\"\'\w]*continuing.*?from.*?where.*?left.*?off.*?[:：]\s*', '', content, flags=re.IGNORECASE)
        content = re.sub(r'^[^\{\[\"\'\w\s]+', '', content)
        content = re.sub(r'\s*```$', '', content.rstrip())
        return content

    def _continue_generation(self, system_prompt: str, user_prompt: str, partial_content: str,
                             timeout: Optional[float] = None, task_id: Optional[str] = None,
                             json_schema: Optional[Dict[str, Any]] = None, max_recursion: int = 2) -> str:
        if max_recursion <= 0:
            logger.warning(f"[ContinueGeneration] 达到最大递归深度，停止续写")
            return ""

        # 如果已生成内容超过30000字符，不再续写，防止无限膨胀
        if len(partial_content) > 30000:
            logger.warning(f"[ContinueGeneration] 已生成内容过长({len(partial_content)}字符)，停止续写")
            return ""

        logger.info(f"[ContinueGeneration] 开始续写，已生成内容长度={len(partial_content)} 字符，剩余递归次数={max_recursion}")

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
            {"role": "assistant", "content": partial_content}
        ]

        api_kwargs = {
            "model": self.model,
            "messages": messages,
            "temperature": 0.1,
            "stream": False,
            "max_tokens": 8000,
            "stop": ["</s>", "\n\n\n"]
        }

        if timeout is not None:
            api_kwargs["timeout"] = timeout

        if json_schema and self._json_schema_supported:
            api_kwargs["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": "output_schema",
                    "schema": json_schema,
                    "strict": True
                }
            }
        else:
            requires_json = "json" in system_prompt.lower() or "json" in user_prompt.lower()
            if requires_json:
                api_kwargs["response_format"] = {"type": "json_object"}

        try:
            response = self.client.chat.completions.create(**api_kwargs)
            note_llm_response(response)

            if response and response.choices and len(response.choices) > 0:
                continued_content = response.choices[0].message.content or ""
                finish_reason = response.choices[0].finish_reason

                logger.info(f"[ContinueGeneration] 续写完成，追加内容长度={len(continued_content)} 字符，finish_reason={finish_reason}")

                continued_content = self._clean_continued_content(continued_content)
                logger.info(f"[ContinueGeneration] 清理后内容长度={len(continued_content)} 字符")

                if finish_reason == 'length':
                    logger.info(f"[ContinueGeneration] 续写内容仍被截断，进行下一轮续写...")
                    new_partial = partial_content + continued_content
                    more_content = self._continue_generation(
                        system_prompt=system_prompt, user_prompt=user_prompt,
                        partial_content=new_partial, timeout=timeout,
                        task_id=task_id, json_schema=json_schema,
                        max_recursion=max_recursion - 1,
                    )
                    return continued_content + more_content

                return continued_content
            else:
                logger.warning("[ContinueGeneration] 续写响应为空")
                return ""

        except Exception as e:
            logger.error(f"[ContinueGeneration] 续写失败：{e}")
            return ""

    async def _async_continue_generation(self, system_prompt: str, user_prompt: str, partial_content: str,
                                          timeout: Optional[float] = None, task_id: Optional[str] = None,
                                          json_schema: Optional[Dict[str, Any]] = None, max_recursion: int = 2) -> str:
        if max_recursion <= 0:
            logger.warning(f"[AsyncContinueGeneration] 达到最大递归深度，停止续写")
            return ""

        # 如果已生成内容超过30000字符，不再续写，防止无限膨胀
        if len(partial_content) > 30000:
            logger.warning(f"[AsyncContinueGeneration] 已生成内容过长({len(partial_content)}字符)，停止续写")
            return ""

        logger.info(f"[AsyncContinueGeneration] 开始续写，已生成内容长度={len(partial_content)} 字符，剩余递归次数={max_recursion}")

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
            {"role": "assistant", "content": partial_content}
        ]

        api_kwargs = {
            "model": self.model,
            "messages": messages,
            "temperature": 0.1,
            "stream": False,
            "max_tokens": 8000,
            "stop": ["</s>", "\n\n\n"]
        }

        if timeout is not None:
            api_kwargs["timeout"] = timeout

        if json_schema and self._json_schema_supported:
            api_kwargs["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": "output_schema",
                    "schema": json_schema,
                    "strict": True
                }
            }
        else:
            requires_json = "json" in system_prompt.lower() or "json" in user_prompt.lower()
            if requires_json:
                api_kwargs["response_format"] = {"type": "json_object"}

        try:
            if not self.async_client:
                result = await asyncio.get_event_loop().run_in_executor(
                    None, lambda: self._continue_generation(
                        system_prompt, user_prompt, partial_content, timeout, task_id, json_schema, max_recursion
                    )
                )
                return result

            response = await self.async_client.chat.completions.create(**api_kwargs)
            note_llm_response(response)

            if response and response.choices and len(response.choices) > 0:
                continued_content = response.choices[0].message.content or ""
                finish_reason = response.choices[0].finish_reason

                logger.info(f"[AsyncContinueGeneration] 续写完成，追加内容长度={len(continued_content)} 字符，finish_reason={finish_reason}")

                continued_content = self._clean_continued_content(continued_content)
                logger.info(f"[AsyncContinueGeneration] 清理后内容长度={len(continued_content)} 字符")

                if finish_reason == 'length':
                    logger.info(f"[AsyncContinueGeneration] 续写内容仍被截断，进行下一轮续写...")
                    new_partial = partial_content + continued_content
                    more_content = await self._async_continue_generation(
                        system_prompt=system_prompt, user_prompt=user_prompt,
                        partial_content=new_partial, timeout=timeout,
                        task_id=task_id, json_schema=json_schema,
                        max_recursion=max_recursion - 1,
                    )
                    return continued_content + more_content

                return continued_content
            else:
                logger.warning("[AsyncContinueGeneration] 续写响应为空")
                return ""

        except Exception as e:
            logger.error(f"[AsyncContinueGeneration] 续写失败：{e}")
            return ""

    def _escape_control_chars_in_json(self, json_str: str) -> str:
        """
        ★ 转义 JSON 字符串值内的控制字符（换行、制表符等）。
        LLM 输出常在字符串值中包含原始换行符，导致 json.loads 失败。
        策略：逐字符扫描，跟踪 in_string 状态，在字符串内遇到控制字符时转义。
        """
        if not json_str:
            return json_str

        json_start = json_str.find('{')
        if json_start == -1:
            return json_str

        result = []
        in_string = False
        escape = False
        changed = False

        for ch in json_str:
            if escape:
                escape = False
                result.append(ch)
                continue
            if ch == '\\' and in_string:
                escape = True
                result.append(ch)
                continue
            if ch == '"':
                in_string = not in_string
                result.append(ch)
                continue
            if in_string:
                if ch == '\n':
                    result.append('\\n')
                    changed = True
                elif ch == '\r':
                    result.append('\\r')
                    changed = True
                elif ch == '\t':
                    result.append('\\t')
                    changed = True
                elif ord(ch) < 0x20:
                    result.append(f'\\u{ord(ch):04x}')
                    changed = True
                else:
                    result.append(ch)
            else:
                result.append(ch)

        if not changed:
            return json_str
        return ''.join(result)

    def _try_fix_json_structure(self, json_str: str) -> str:
        balance = 0
        result = json_str

        obj_stack = []
        for i, char in enumerate(result):
            if char == '{':
                obj_stack.append(char)
            elif char == '}':
                if obj_stack:
                    obj_stack.pop()

        while obj_stack:
            result += '}'
            obj_stack.pop()

        arr_stack = []
        for i, char in enumerate(result):
            if char == '[':
                arr_stack.append(char)
            elif char == ']':
                if arr_stack:
                    arr_stack.pop()

        while arr_stack:
            result += ']'
            arr_stack.pop()

        if result.endswith(','):
            result = result.rstrip(',')

        return result

    def call_llm_stream(self, system_prompt: str, user_prompt: str,
                        timeout: Optional[float] = None) -> Iterator[str]:
        """流式文本生成（M5 问答 SSE，07 §4）：逐 delta 产出 content 片段。

        与 call_llm_text 不同：不重试（中途重试会导致已发出的 token 重复）、
        不做 JSON 修复（问答为纯文本）。异常直接上抛由路由层转 SSE error 事件。
        """
        api_kwargs = {
            "model": getattr(self, 'model', 'unknown-model'),
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": 0.1,
            "stream": True,
            "max_tokens": 8000,
        }
        if timeout is not None:
            api_kwargs["timeout"] = timeout

        logger.info(f"[LLM] 流式生成开始：model={api_kwargs['model']}，user_prompt={len(user_prompt)} 字符")
        from app.services.pipeline_profiler import begin_llm_call, finish_llm_call

        _scope = begin_llm_call(
            model=api_kwargs["model"], stream=True,
            system_prompt=system_prompt, user_prompt=user_prompt,
            caller="LLMClient.call_llm_stream")
        try:
            response = self.client.chat.completions.create(**api_kwargs)
            chunk_count = 0
            try:
                for chunk in response:
                    note_llm_chunk(chunk)
                    if chunk.choices and chunk.choices[0].delta and chunk.choices[0].delta.content:
                        chunk_count += 1
                        yield chunk.choices[0].delta.content
            except GeneratorExit:
                if hasattr(response, 'close'):
                    try:
                        response.close()
                    except Exception:
                        pass
                raise
            logger.info(f"[LLM] 流式生成完成：{chunk_count} 个 chunk")
        finally:
            finish_llm_call(_scope)

    @_profile_llm_call
    def call_llm_text(self, system_prompt: str, user_prompt: str, max_retries: int = 3, stream: bool = False,
                      timeout: Optional[float] = None, task_id: Optional[str] = None,
                      temperature: Optional[float] = None) -> Dict[str, Any]:
        from app.infrastructure.task_manager import task_manager
        model_name = getattr(self, 'model', 'unknown-model')
        call_start_time = time.time()
        timeout_str = f"{timeout}s" if timeout else "default"
        logger.info(f"正在发起 LLM 调用（文本模式）：model={model_name}, stream={stream}, timeout={timeout_str}")
        logger.info(f"[LLM] 请求内容长度：system_prompt={len(system_prompt)} 字符，user_prompt={len(user_prompt)} 字符")
        if task_id:
            logger.info(f"[LLM] 任务 ID: {task_id}，将在流式响应中检查取消状态")

        for attempt in range(max_retries):
            note_llm_attempt()
            response = None
            try:
                api_kwargs = {
                    "model": model_name,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    "temperature": temperature if temperature is not None else 0.1,
                    "stream": stream,
                    "max_tokens": 16000,
                    "stop": ["</s>", "\n\n\n"]
                }

                if timeout is not None:
                    api_kwargs["timeout"] = timeout

                # 硬闸与 call_llm 同款：自定义 http_client 下 SDK 超时不可靠，
                # 文本通道裸调曾实测挂 13 分钟（结果确认阶段慢的元凶之一）
                response = self._create_with_hard_gate(api_kwargs, timeout)
                if not stream:
                    note_llm_response(response)

                if stream:
                    logger.info(f"[LLM] 开始接收流式响应...")
                    stream_start = time.time()
                    full_content = ""
                    chunk_count = 0
                    stream_timeout = timeout if timeout is not None else 120.0
                    try:
                        for chunk in response:
                            if task_id and task_manager.is_cancelled(task_id):
                                logger.info(f"[LLM] 检测到任务取消，中断流式响应 (已接收 {chunk_count} 个 chunk)")
                                if hasattr(response, 'close'):
                                    try:
                                        response.close()
                                    except Exception:
                                        pass
                                raise TaskCancelledError(f"Task {task_id} was cancelled during streaming")

                            note_llm_chunk(chunk)
                            elapsed_time = time.time() - stream_start
                            if elapsed_time > stream_timeout:
                                logger.error(f"LLM 调用超时（timeout={stream_timeout}s），中断流式响应")
                                if hasattr(response, 'close'):
                                    try:
                                        response.close()
                                    except Exception:
                                        pass
                                raise TimeoutError(f"LLM streaming response timeout after {elapsed_time:.2f}s")

                            if chunk.choices and chunk.choices[0].delta.content:
                                full_content += chunk.choices[0].delta.content
                                chunk_count += 1
                                if len(full_content) > 60000:
                                    if hasattr(response, 'close'):
                                        try:
                                            response.close()
                                        except Exception:
                                            pass
                                    raise TimeoutError(
                                        f"LLM 流式响应超长（>{len(full_content)} 字符），疑似失控生成")
                                if chunk_count % 50 == 0:
                                    logger.info(f"[LLM] 已接收 {chunk_count} 个 chunk, 当前内容长度={len(full_content)} 字符，耗时={time.time()-stream_start:.2f}s")
                        logger.info(f"[LLM] 流式响应完成，总内容长度={len(full_content)} 字符，总耗时={time.time()-stream_start:.2f}s")
                        return {"content": full_content}
                    except GeneratorExit:
                        if response and hasattr(response, 'close'):
                            try:
                                response.close()
                            except Exception:
                                pass
                        raise
                else:
                    if not response or not response.choices:
                        logger.warning("LLM 响应为空或无选择项，返回空字符串")
                        return {"content": ""}
                    if len(response.choices) == 0:
                        logger.warning("LLM 响应中 choices 为空，返回空字符串")
                        return {"content": ""}
                    message_content = response.choices[0].message.content
                    if message_content is None:
                        logger.warning("LLM 响应内容为空，返回空字符串")
                        return {"content": ""}
                    logger.info(f"[LLM] 非流式响应，内容长度={len(message_content)} 字符")
                    return {"content": message_content}

            except TaskCancelledError as e:
                logger.info(f"任务被取消，停止重试：{e}")
                if response and hasattr(response, 'close'):
                    try:
                        response.close()
                    except Exception:
                        pass
                raise
            except TimeoutError as e:
                # 硬闸超时=服务挂起，属端点级失败：连续出现即熔断并转不可达异常，
                # 让上层快速失败而不是把重试预算烧在一个已死的服务上
                opened = self._register_endpoint_failure(e)
                if opened:
                    raise LLMEndpointUnreachableError(
                        f"模型服务持续无响应（连续调用硬超时）：{e}") from e
                if response and hasattr(response, 'close'):
                    try:
                        response.close()
                    except Exception:
                        pass
                raise
            except Exception as e:
                if response and hasattr(response, 'close'):
                    try:
                        response.close()
                    except Exception:
                        pass
                # 连接类失败（拒绝/DNS/不可达）：重试毫无意义，立即转不可达异常
                # 中止本调用；连续两次打开熔断，后续调用秒败（2026-11-08 根修）
                if self._is_connection_error(e):
                    opened = self._register_endpoint_failure(e)
                    logger.error(f"模型服务连接失败（熔断{'已' if opened else '未'}打开，"
                                 f"连续失败 {self._endpoint_fail_streak} 次）：{e}")
                    raise LLMEndpointUnreachableError(f"模型服务连接失败：{e}") from e
                if self._is_read_timeout(e) and self._register_endpoint_failure(e):
                    raise LLMEndpointUnreachableError(
                        f"模型服务持续超时（连续多次无响应）：{e}") from e
                err_msg = str(e).lower()
                if self._is_json_schema_unsupported(e):
                    self._json_schema_supported = False
                    logger.warning(f"[LLM] 当前模型不支持 json_schema 约束输出，本次会话降级为 json_object 模式重试: {e}")
                    continue
                if "429" in err_msg or "rate limit" in err_msg:
                    wait_time = (attempt + 1) * 10
                    logger.warning(f"触发 API 限流，正在进行第 {attempt+1} 次重试，等待 {wait_time} 秒...")
                    note_llm_retry_wait(wait_time)
                    time.sleep(wait_time)
                elif attempt < max_retries - 1:
                    logger.warning(f"LLM 调用失败：{e}，正在重试... (尝试 {attempt+1}/{max_retries}, 已耗时={time.time()-call_start_time:.2f}s)")
                    note_llm_retry_wait(2)
                    time.sleep(2)
                else:
                    total_time = time.time() - call_start_time
                    logger.error(f"LLM 调用在 {max_retries} 次尝试后仍然失败，总耗时={total_time:.2f}s: {str(e)}")
                    raise Exception(f"LLM 调用在 {max_retries} 次尝试后仍然失败，总耗时={total_time:.2f}s: {str(e)}")

    @_profile_llm_call
    async def async_call_llm_text(self, system_prompt: str, user_prompt: str, max_retries: int = 3,
                                  stream: bool = False, timeout: Optional[float] = None,
                                  task_id: Optional[str] = None) -> Dict[str, Any]:
        from app.infrastructure.task_manager import task_manager
        model_name = getattr(self, 'model', 'unknown-model')
        call_start_time = time.time()
        timeout_str = f"{timeout}s" if timeout else "default"
        logger.info(f"正在发起异步 LLM 调用（文本模式）：model={model_name}, stream={stream}, timeout={timeout_str}")

        if not self.async_client:
            return await asyncio.get_event_loop().run_in_executor(
                None, lambda: self.call_llm_text(system_prompt, user_prompt, max_retries, stream, timeout, task_id)
            )

        for attempt in range(max_retries):
            note_llm_attempt()
            response = None
            try:
                api_kwargs = {
                    "model": model_name,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    "temperature": 0.1,
                    "stream": stream,
                    "max_tokens": 16000,
                    "stop": ["</s>", "\n\n\n"]
                }

                if timeout is not None:
                    api_kwargs["timeout"] = timeout

                response = await self.async_client.chat.completions.create(**api_kwargs)
                if not stream:
                    note_llm_response(response)

                if stream:
                    stream_start = time.time()
                    full_content = ""
                    chunk_count = 0
                    stream_timeout = timeout if timeout is not None else 120.0
                    async for chunk in response:
                        if task_id and task_manager.is_cancelled(task_id):
                            if hasattr(response, 'aclose'):
                                try:
                                    await response.aclose()
                                except Exception:
                                    pass
                            raise TaskCancelledError(f"Task {task_id} was cancelled during streaming")

                        note_llm_chunk(chunk)
                        elapsed_time = time.time() - stream_start
                        if elapsed_time > stream_timeout:
                            if hasattr(response, 'aclose'):
                                try:
                                    await response.aclose()
                                except Exception:
                                    pass
                            raise TimeoutError(f"LLM streaming response timeout after {elapsed_time:.2f}s")

                        if chunk.choices and chunk.choices[0].delta.content:
                            full_content += chunk.choices[0].delta.content
                            chunk_count += 1
                            if len(full_content) > 60000:
                                if hasattr(response, 'aclose'):
                                    try:
                                        await response.aclose()
                                    except Exception:
                                        pass
                                raise TimeoutError(
                                    f"LLM 流式响应超长（>{len(full_content)} 字符），疑似失控生成")
                            if chunk_count % 50 == 0:
                                logger.info(f"[AsyncLLM] 已接收 {chunk_count} 个 chunk, 当前内容长度={len(full_content)} 字符，耗时={time.time()-stream_start:.2f}s")

                    logger.info(f"[AsyncLLM] 流式响应完成，总内容长度={len(full_content)} 字符，总耗时={time.time()-stream_start:.2f}s")
                    return {"content": full_content}
                else:
                    if not response or not response.choices:
                        return {"content": ""}
                    if len(response.choices) == 0:
                        return {"content": ""}
                    message_content = response.choices[0].message.content
                    if message_content is None:
                        return {"content": ""}
                    logger.info(f"[AsyncLLM] 非流式响应，内容长度={len(message_content)} 字符")
                    return {"content": message_content}

            except TaskCancelledError as e:
                logger.info(f"[AsyncLLM] 任务被取消，停止重试：{e}")
                if response and hasattr(response, 'aclose'):
                    try:
                        await response.aclose()
                    except Exception:
                        pass
                raise
            except TimeoutError as e:
                opened = self._register_endpoint_failure(e)
                if opened:
                    raise LLMEndpointUnreachableError(
                        f"模型服务持续无响应（连续调用硬超时）：{e}") from e
                if response and hasattr(response, 'aclose'):
                    try:
                        await response.aclose()
                    except Exception:
                        pass
                raise
            except Exception as e:
                if response and hasattr(response, 'aclose'):
                    try:
                        await response.aclose()
                    except Exception:
                        pass
                if self._is_connection_error(e):
                    opened = self._register_endpoint_failure(e)
                    logger.error(f"模型服务连接失败（熔断{'已' if opened else '未'}打开，"
                                 f"连续失败 {self._endpoint_fail_streak} 次）：{e}")
                    raise LLMEndpointUnreachableError(f"模型服务连接失败：{e}") from e
                if self._is_read_timeout(e) and self._register_endpoint_failure(e):
                    raise LLMEndpointUnreachableError(
                        f"模型服务持续超时（连续多次无响应）：{e}") from e
                err_msg = str(e).lower()
                if self._is_json_schema_unsupported(e):
                    self._json_schema_supported = False
                    logger.warning(f"[LLM] 当前模型不支持 json_schema 约束输出，本次会话降级为 json_object 模式重试: {e}")
                    continue
                if "429" in err_msg or "rate limit" in err_msg:
                    wait_time = (attempt + 1) * 10
                    logger.warning(f"[AsyncLLM] 触发 API 限流，等待 {wait_time} 秒...")
                    note_llm_retry_wait(wait_time)
                    await asyncio.sleep(wait_time)
                elif attempt < max_retries - 1:
                    logger.warning(f"[AsyncLLM] 调用失败：{e}，正在重试... (尝试 {attempt+1}/{max_retries})")
                    note_llm_retry_wait(2)
                    await asyncio.sleep(2)
                else:
                    total_time = time.time() - call_start_time
                    logger.error(f"[AsyncLLM] 调用在 {max_retries} 次尝试后仍然失败，总耗时={total_time:.2f}s: {str(e)}")
                    raise Exception(f"LLM 调用在 {max_retries} 次尝试后仍然失败，总耗时={total_time:.2f}s: {str(e)}")
